import { useState, useEffect, useCallback } from 'react';
import { Trash2, Globe, AlertTriangle, Clock } from 'lucide-react';
import { fetchCommands, deleteCommand, clearAllCommands } from '@/services/db';
import type { CommandRecord, Language } from '@/types';

const LANG_LABELS: Record<Language, string> = { hi: 'Hindi', en: 'English', hinglish: 'Hinglish' };
const PRIORITY_COLORS: Record<string, string> = {
  critical: 'bg-red-100 text-red-700',
  high: 'bg-amber-100 text-amber-700',
  normal: 'bg-blue-100 text-blue-700',
  low: 'bg-stone-100 text-stone-600',
};

export default function HistoryPage() {
  const [commands, setCommands] = useState<CommandRecord[]>([]);
  const [loading, setLoading] = useState(true);
  const [expanded, setExpanded] = useState<string | null>(null);

  const load = useCallback(async () => {
    setLoading(true);
    const data = await fetchCommands();
    setCommands(data);
    setLoading(false);
  }, []);

  useEffect(() => { load(); }, [load]);

  const handleDelete = async (id: string) => {
    await deleteCommand(id);
    load();
  };

  const handleClearAll = async () => {
    await clearAllCommands();
    load();
  };

  // Group by time period
  const now = new Date();
  const today: CommandRecord[] = [];
  const thisWeek: CommandRecord[] = [];
  const older: CommandRecord[] = [];

  for (const cmd of commands) {
    const created = new Date(cmd.created_at || now.toISOString());
    const diffMs = now.getTime() - created.getTime();
    const diffDays = diffMs / 86400000;
    if (diffDays < 1) today.push(cmd);
    else if (diffDays < 7) thisWeek.push(cmd);
    else older.push(cmd);
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-stone-900">Command History</h1>
          <p className="text-sm text-stone-500 mt-0.5">Every command processed through the Wani pipeline</p>
        </div>
        {commands.length > 0 && (
          <button
            onClick={handleClearAll}
            className="flex items-center gap-1.5 px-3 py-2 text-sm text-stone-600 hover:text-red-600 transition-colors"
          >
            <Trash2 className="w-4 h-4" />
            Clear All
          </button>
        )}
      </div>

      {loading ? (
        <p className="text-sm text-stone-400">Loading history...</p>
      ) : commands.length === 0 ? (
        <div className="bg-white rounded-2xl border border-stone-200 p-12 text-center">
          <p className="text-sm text-stone-400">No commands yet. Start by speaking or typing to Wani.</p>
        </div>
      ) : (
        <div className="space-y-6">
          <Section title="Today" items={today} expanded={expanded} setExpanded={setExpanded} onDelete={handleDelete} />
          <Section title="This Week" items={thisWeek} expanded={expanded} setExpanded={setExpanded} onDelete={handleDelete} />
          {older.length > 0 && (
            <Section title="Older" items={older} expanded={expanded} setExpanded={setExpanded} onDelete={handleDelete} />
          )}
        </div>
      )}
    </div>
  );
}

function Section({ title, items, expanded, setExpanded, onDelete }: {
  title: string;
  items: CommandRecord[];
  expanded: string | null;
  setExpanded: (id: string | null) => void;
  onDelete: (id: string) => void;
}) {
  if (items.length === 0) return null;
  return (
    <div>
      <h2 className="text-xs font-semibold text-stone-400 uppercase tracking-wide mb-3">{title} ({items.length})</h2>
      <div className="space-y-2">
        {items.map((cmd) => (
          <div key={cmd.id} className="bg-white rounded-xl border border-stone-200 overflow-hidden">
            <div
              className="p-4 cursor-pointer hover:bg-stone-50 transition-colors"
              onClick={() => setExpanded(expanded === cmd.id ? null : cmd.id!)}
            >
              <div className="flex items-start justify-between gap-3">
                <div className="flex-1 min-w-0">
                  <p className="text-sm font-medium text-stone-900 truncate">"{cmd.transcript}"</p>
                  <div className="flex items-center gap-2 mt-1.5 flex-wrap">
                    <span className="flex items-center gap-1 text-[10px] text-stone-500">
                      <Globe className="w-3 h-3" />
                      {LANG_LABELS[cmd.language as Language] || cmd.language}
                    </span>
                    <span className="text-[10px] text-stone-400">·</span>
                    <span className="text-[10px] text-stone-500 capitalize">{cmd.intent?.replace(/_/g, ' ')}</span>
                    <span className={`text-[10px] px-2 py-0.5 rounded-full font-medium ${PRIORITY_COLORS[cmd.priority] || ''}`}>
                      {cmd.priority}
                    </span>
                    <span className="flex items-center gap-0.5 text-[10px] text-stone-400">
                      <Clock className="w-3 h-3" />
                      {new Date(cmd.created_at || '').toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                    </span>
                  </div>
                </div>
                <button
                  onClick={(e) => { e.stopPropagation(); onDelete(cmd.id!); }}
                  className="p-1.5 text-stone-300 hover:text-red-500 transition-colors"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>

            {expanded === cmd.id && (
              <div className="px-4 pb-4 border-t border-stone-50 pt-3">
                {cmd.priority === 'critical' && (
                  <div className="flex items-center gap-2 mb-2">
                    <AlertTriangle className="w-3.5 h-3.5 text-red-500" />
                    <span className="text-xs font-medium text-red-600">Emergency Command</span>
                  </div>
                )}
                <p className="text-xs font-semibold text-stone-500 mb-1">Pipeline Trace</p>
                <div className="space-y-1 mb-3">
                  {(cmd.pipeline_trace as any[])?.map((step, i) => (
                    <div key={i} className="flex items-center gap-2 text-xs">
                      <span className={`w-1.5 h-1.5 rounded-full ${step.status === 'done' ? 'bg-emerald-500' : 'bg-stone-300'}`} />
                      <span className="text-stone-600">{step.step.replace(/_/g, ' ')}</span>
                      {step.durationMs && <span className="text-stone-300">{(step.durationMs / 1000).toFixed(1)}s</span>}
                    </div>
                  ))}
                </div>
                <p className="text-xs font-semibold text-stone-500 mb-1">Response</p>
                <pre className="text-xs text-stone-700 whitespace-pre-wrap bg-stone-50 p-3 rounded-lg">{cmd.response_text}</pre>
              </div>
            )}
          </div>
        ))}
      </div>
    </div>
  );
}
