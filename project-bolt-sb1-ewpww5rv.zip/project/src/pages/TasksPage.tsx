import { useState, useEffect, useCallback } from 'react';
import { Plus, Trash2, Check, X, Pencil, Circle } from 'lucide-react';
import { fetchTasks, saveTask, deleteTask } from '@/services/db';
import type { TaskRecord, TaskStatus, Priority } from '@/types';

const PRIORITY_COLORS: Record<Priority, string> = {
  critical: 'bg-red-100 text-red-700 border-red-200',
  high: 'bg-amber-100 text-amber-700 border-amber-200',
  normal: 'bg-blue-100 text-blue-700 border-blue-200',
  low: 'bg-stone-100 text-stone-600 border-stone-200',
};

const STATUS_ICONS: Record<TaskStatus, React.ReactNode> = {
  pending: <Circle className="w-3.5 h-3.5" />,
  in_progress: <Circle className="w-3.5 h-3.5 text-amber-500 fill-amber-300" />,
  completed: <Check className="w-3.5 h-3.5 text-emerald-600" />,
  cancelled: <X className="w-3.5 h-3.5 text-stone-400" />,
};

export default function TasksPage() {
  const [tasks, setTasks] = useState<TaskRecord[]>([]);
  const [loading, setLoading] = useState(true);
  const [editing, setEditing] = useState<TaskRecord | null>(null);
  const [showForm, setShowForm] = useState(false);
  const [formData, setFormData] = useState({
    title: '',
    description: '',
    priority: 'normal' as Priority,
    status: 'pending' as TaskStatus,
    location_text: '',
  });

  const load = useCallback(async () => {
    setLoading(true);
    const data = await fetchTasks();
    setTasks(data);
    setLoading(false);
  }, []);

  useEffect(() => { load(); }, [load]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.title.trim()) return;
    await saveTask({
      ...formData,
      ...(editing?.id ? { id: editing.id } : {}),
    });
    setShowForm(false);
    setEditing(null);
    setFormData({ title: '', description: '', priority: 'normal', status: 'pending', location_text: '' });
    load();
  };

  const handleEdit = (task: TaskRecord) => {
    setEditing(task);
    setFormData({
      title: task.title,
      description: task.description || '',
      priority: task.priority,
      status: task.status,
      location_text: task.location_text || '',
    });
    setShowForm(true);
  };

  const handleStatusChange = async (task: TaskRecord, status: TaskStatus) => {
    await saveTask({ ...task, status });
    load();
  };

  const handleDelete = async (id: string) => {
    await deleteTask(id);
    load();
  };

  const pending = tasks.filter((t) => t.status === 'pending' || t.status === 'in_progress');
  const completed = tasks.filter((t) => t.status === 'completed');

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-stone-900">Tasks</h1>
          <p className="text-sm text-stone-500 mt-0.5">Manage action items created by Wani or manually</p>
        </div>
        <button
          onClick={() => { setEditing(null); setFormData({ title: '', description: '', priority: 'normal', status: 'pending', location_text: '' }); setShowForm(true); }}
          className="flex items-center gap-1.5 px-4 py-2.5 bg-stone-900 hover:bg-stone-800 text-white rounded-xl text-sm font-medium transition-colors"
        >
          <Plus className="w-4 h-4" />
          New Task
        </button>
      </div>

      {showForm && (
        <form onSubmit={handleSubmit} className="bg-white rounded-2xl border border-stone-200 p-5 space-y-4">
          <input
            type="text"
            placeholder="Task title"
            value={formData.title}
            onChange={(e) => setFormData({ ...formData, title: e.target.value })}
            className="w-full px-3.5 py-2.5 bg-stone-50 border border-stone-200 rounded-xl text-sm focus:outline-none focus:border-stone-400"
            autoFocus
          />
          <textarea
            placeholder="Description"
            value={formData.description}
            onChange={(e) => setFormData({ ...formData, description: e.target.value })}
            rows={2}
            className="w-full px-3.5 py-2.5 bg-stone-50 border border-stone-200 rounded-xl text-sm focus:outline-none focus:border-stone-400 resize-none"
          />
          <div className="grid grid-cols-3 gap-3">
            <select
              value={formData.priority}
              onChange={(e) => setFormData({ ...formData, priority: e.target.value as Priority })}
              className="px-3 py-2.5 bg-stone-50 border border-stone-200 rounded-xl text-sm focus:outline-none focus:border-stone-400"
            >
              <option value="critical">Critical</option>
              <option value="high">High</option>
              <option value="normal">Normal</option>
              <option value="low">Low</option>
            </select>
            <select
              value={formData.status}
              onChange={(e) => setFormData({ ...formData, status: e.target.value as TaskStatus })}
              className="px-3 py-2.5 bg-stone-50 border border-stone-200 rounded-xl text-sm focus:outline-none focus:border-stone-400"
            >
              <option value="pending">Pending</option>
              <option value="in_progress">In Progress</option>
              <option value="completed">Completed</option>
              <option value="cancelled">Cancelled</option>
            </select>
            <input
              type="text"
              placeholder="Location (optional)"
              value={formData.location_text}
              onChange={(e) => setFormData({ ...formData, location_text: e.target.value })}
              className="px-3 py-2.5 bg-stone-50 border border-stone-200 rounded-xl text-sm focus:outline-none focus:border-stone-400"
            />
          </div>
          <div className="flex gap-2">
            <button type="submit" className="px-4 py-2 bg-stone-900 hover:bg-stone-800 text-white rounded-xl text-sm font-medium transition-colors">
              {editing ? 'Update' : 'Create'}
            </button>
            <button type="button" onClick={() => { setShowForm(false); setEditing(null); }} className="px-4 py-2 text-stone-600 hover:text-stone-900 text-sm font-medium">
              Cancel
            </button>
          </div>
        </form>
      )}

      {loading ? (
        <p className="text-sm text-stone-400">Loading tasks...</p>
      ) : tasks.length === 0 ? (
        <div className="bg-white rounded-2xl border border-stone-200 p-12 text-center">
          <p className="text-sm text-stone-400">No tasks yet. Create one or ask Wani to help.</p>
        </div>
      ) : (
        <>
          {pending.length > 0 && (
            <div>
              <h2 className="text-xs font-semibold text-stone-400 uppercase tracking-wide mb-3">Active ({pending.length})</h2>
              <div className="space-y-2">
                {pending.map((task) => (
                  <TaskRow
                    key={task.id}
                    task={task}
                    onEdit={() => handleEdit(task)}
                    onDelete={() => handleDelete(task.id!)}
                    onComplete={() => handleStatusChange(task, 'completed')}
                    onCancel={() => handleStatusChange(task, 'cancelled')}
                  />
                ))}
              </div>
            </div>
          )}
          {completed.length > 0 && (
            <div>
              <h2 className="text-xs font-semibold text-stone-400 uppercase tracking-wide mb-3">Completed ({completed.length})</h2>
              <div className="space-y-2">
                {completed.map((task) => (
                  <TaskRow
                    key={task.id}
                    task={task}
                    onEdit={() => handleEdit(task)}
                    onDelete={() => handleDelete(task.id!)}
                    onComplete={() => {}}
                    onCancel={() => handleStatusChange(task, 'pending')}
                  />
                ))}
              </div>
            </div>
          )}
        </>
      )}
    </div>
  );
}

function TaskRow({ task, onEdit, onDelete, onComplete, onCancel }: {
  task: TaskRecord;
  onEdit: () => void;
  onDelete: () => void;
  onComplete: () => void;
  onCancel: () => void;
}) {
  const isDone = task.status === 'completed';
  return (
    <div className={`bg-white rounded-xl border border-stone-200 p-4 flex items-start gap-3 ${isDone ? 'opacity-60' : ''}`}>
      <button
        onClick={onComplete}
        className="flex-shrink-0 mt-0.5 w-5 h-5 rounded-full border-2 border-stone-300 hover:border-emerald-500 flex items-center justify-center transition-colors"
        aria-label="Complete task"
      >
        {isDone && <Check className="w-3 h-3 text-emerald-600" />}
      </button>

      <div className="flex-1 min-w-0">
        <p className={`text-sm font-medium ${isDone ? 'line-through text-stone-400' : 'text-stone-900'}`}>{task.title}</p>
        {task.description && <p className="text-xs text-stone-500 mt-0.5">{task.description}</p>}
        <div className="flex items-center gap-2 mt-2">
          <span className={`text-[10px] px-2 py-0.5 rounded-full border font-medium ${PRIORITY_COLORS[task.priority]}`}>
            {task.priority}
          </span>
          {task.location_text && (
            <span className="text-[10px] text-stone-400">{task.location_text}</span>
          )}
          {task.created_at && (
            <span className="text-[10px] text-stone-300">{new Date(task.created_at).toLocaleDateString()}</span>
          )}
        </div>
      </div>

      <div className="flex items-center gap-1">
        {!isDone && (
          <button onClick={onCancel} className="p-1.5 text-stone-400 hover:text-stone-600 transition-colors" aria-label="Cancel task">
            {STATUS_ICONS.cancelled}
          </button>
        )}
        <button onClick={onEdit} className="p-1.5 text-stone-400 hover:text-stone-600 transition-colors" aria-label="Edit task">
          <Pencil className="w-3.5 h-3.5" />
        </button>
        <button onClick={onDelete} className="p-1.5 text-stone-400 hover:text-red-500 transition-colors" aria-label="Delete task">
          <Trash2 className="w-3.5 h-3.5" />
        </button>
      </div>
    </div>
  );
}
