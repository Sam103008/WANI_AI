import { useSpeechSynthesis } from '@/hooks/useSpeechSynthesis';
import { Volume2, VolumeX, Globe, Info, Shield, MapPin } from 'lucide-react';
import { useState, useEffect } from 'react';

export default function SettingsPage() {
  const { is_enabled, toggle, isSupported: ttsSupported } = useSpeechSynthesis();
  const [responseLang, setResponseLang] = useState<string>(() => localStorage.getItem('wani_response_lang') || 'auto');
  const [highContrast, setHighContrast] = useState(false);
  const [largeText, setLargeText] = useState(false);

  useEffect(() => {
    localStorage.setItem('wani_response_lang', responseLang);
  }, [responseLang]);

  return (
    <div className="max-w-2xl space-y-6">
      <div>
        <h1 className="text-2xl font-bold text-stone-900">Settings</h1>
        <p className="text-sm text-stone-500 mt-0.5">Customize Wani to your preferences</p>
      </div>

      {/* Voice Settings */}
      <div className="bg-white rounded-2xl border border-stone-200 overflow-hidden">
        <div className="px-5 py-4 border-b border-stone-100">
          <h2 className="text-sm font-semibold text-stone-900 flex items-center gap-2">
            <Volume2 className="w-4 h-4 text-stone-600" />
            Voice
          </h2>
        </div>
        <div className="divide-y divide-stone-50">
          <SettingRow label="Voice responses" description={ttsSupported ? 'Read results aloud after processing' : 'Text-to-speech not supported in this browser'}>
            <button
              onClick={toggle}
              disabled={!ttsSupported}
              className={`relative w-11 h-6 rounded-full transition-colors ${is_enabled ? 'bg-stone-900' : 'bg-stone-200'} disabled:opacity-40`}
            >
              <span className={`absolute top-0.5 w-5 h-5 rounded-full bg-white shadow transition-transform ${is_enabled ? 'translate-x-5' : 'translate-x-0.5'}`} />
            </button>
          </SettingRow>

          <SettingRow label="Response language" description="Language for voice responses">
            <select
              value={responseLang}
              onChange={(e) => setResponseLang(e.target.value)}
              className="px-3 py-2 bg-stone-50 border border-stone-200 rounded-lg text-sm focus:outline-none focus:border-stone-400"
            >
              <option value="auto">Auto (match input)</option>
              <option value="en">English</option>
              <option value="hi">Hindi</option>
            </select>
          </SettingRow>
        </div>
      </div>

      {/* Accessibility Settings */}
      <div className="bg-white rounded-2xl border border-stone-200 overflow-hidden">
        <div className="px-5 py-4 border-b border-stone-100">
          <h2 className="text-sm font-semibold text-stone-900 flex items-center gap-2">
            <Globe className="w-4 h-4 text-stone-600" />
            Accessibility
          </h2>
        </div>
        <div className="divide-y divide-stone-50">
          <SettingRow label="Large text" description="Increase text size for better readability">
            <button
              onClick={() => setLargeText(!largeText)}
              className={`relative w-11 h-6 rounded-full transition-colors ${largeText ? 'bg-stone-900' : 'bg-stone-200'}`}
            >
              <span className={`absolute top-0.5 w-5 h-5 rounded-full bg-white shadow transition-transform ${largeText ? 'translate-x-5' : 'translate-x-0.5'}`} />
            </button>
          </SettingRow>
          <SettingRow label="High contrast" description="Increase visual contrast for better visibility">
            <button
              onClick={() => setHighContrast(!highContrast)}
              className={`relative w-11 h-6 rounded-full transition-colors ${highContrast ? 'bg-stone-900' : 'bg-stone-200'}`}
            >
              <span className={`absolute top-0.5 w-5 h-5 rounded-full bg-white shadow transition-transform ${highContrast ? 'translate-x-5' : 'translate-x-0.5'}`} />
            </button>
          </SettingRow>
        </div>
      </div>

      {/* Privacy / Info */}
      <div className="bg-white rounded-2xl border border-stone-200 overflow-hidden">
        <div className="px-5 py-4 border-b border-stone-100">
          <h2 className="text-sm font-semibold text-stone-900 flex items-center gap-2">
            <Shield className="w-4 h-4 text-stone-600" />
            Privacy & Safety
          </h2>
        </div>
        <div className="p-5 space-y-3 text-sm text-stone-600">
          <div className="flex items-start gap-2.5">
            <MapPin className="w-4 h-4 text-stone-400 mt-0.5 flex-shrink-0" />
            <p>Location is requested only when needed (hospital search, routing). Demo location is used when permission is denied.</p>
          </div>
          <div className="flex items-start gap-2.5">
            <Info className="w-4 h-4 text-stone-400 mt-0.5 flex-shrink-0" />
            <p>Voice input uses the browser Web Speech API. No audio is stored — only the transcript is saved.</p>
          </div>
          <div className="flex items-start gap-2.5">
            <Shield className="w-4 h-4 text-stone-400 mt-0.5 flex-shrink-0" />
            <p>Emergency dispatch requires explicit user confirmation. Wani does not automatically call emergency services.</p>
          </div>
        </div>
      </div>
    </div>
  );
}

function SettingRow({ label, description, children }: { label: string; description: string; children: React.ReactNode }) {
  return (
    <div className="flex items-center justify-between px-5 py-4">
      <div className="flex-1 pr-4">
        <p className="text-sm font-medium text-stone-900">{label}</p>
        <p className="text-xs text-stone-500 mt-0.5">{description}</p>
      </div>
      {children}
    </div>
  );
}
