import { useState, useCallback, useRef, useEffect } from 'react';
import { Send, AlertTriangle, Bell, Plane, Accessibility, Sparkles } from 'lucide-react';
import MicButton from '@/components/MicButton';
import PipelineVisualizer from '@/components/PipelineVisualizer';
import ResultPanel from '@/components/ResultPanel';
import { useSpeechRecognition } from '@/hooks/useSpeechRecognition';
import { useSpeechSynthesis } from '@/hooks/useSpeechSynthesis';
import { useGeolocation } from '@/hooks/useGeolocation';
import { runAgentPipeline } from '@/services/agentPipeline';
import { saveCommand, saveTask, saveReminder, saveTrip, saveIncident, fetchTasks, fetchReminders } from '@/services/db';
import type { MicState, AgentResult, GeoLocation } from '@/types';
import { QUICK_ACTIONS } from '@/data/sampleCommands';
import { Link } from 'react-router-dom';

export default function Dashboard() {
  const [micState, setMicState] = useState<MicState>('idle');
  const [pipelineSteps, setPipelineSteps] = useState<AgentResult['pipeline']>([]);
  const [result, setResult] = useState<AgentResult | null>(null);
  const [explanation, setExplanation] = useState<string>('');
  const [textCommand, setTextCommand] = useState('');
  const [processing, setProcessing] = useState(false);
  const [activeTasks, setActiveTasks] = useState(0);
  const [upcomingReminders, setUpcomingReminders] = useState(0);
  const [emergencyActive, setEmergencyActive] = useState(false);

  const { speak, is_enabled: voiceEnabled, toggle: toggleVoice } = useSpeechSynthesis({ preferredLang: 'en-IN' });
  const { getLocation } = useGeolocation();
  const processingRef = useRef(false);

  // Load task/reminder counts on mount
  useEffect(() => {
    fetchTasks().then((tasks) => {
      setActiveTasks(tasks.filter((t) => t.status === 'pending' || t.status === 'in_progress').length);
    });
    fetchReminders().then((reminders) => {
      setUpcomingReminders(reminders.filter((r) => r.status === 'pending').length);
    });
  }, []);

  const processCommand = useCallback(
    async (transcript: string) => {
      if (processingRef.current) return;
      processingRef.current = true;
      setProcessing(true);
      setResult(null);
      setPipelineSteps([]);
      setExplanation('');
      setMicState('processing');

      // Get browser location if available
      let browserLoc: GeoLocation | undefined;
      const loc = await getLocation();
      if (loc) browserLoc = loc;

      setMicState('understanding');
      await new Promise((r) => setTimeout(r, 200));

      setMicState('executing');
      const agentResult = await runAgentPipeline(transcript, browserLoc);

      // Update pipeline steps progressively
      setPipelineSteps(agentResult.pipeline);
      setResult(agentResult);
      setExplanation(agentResult.explanation);

      // Check emergency
      if (agentResult.intent.isEmergency) {
        setEmergencyActive(true);
      } else {
        setEmergencyActive(false);
      }

      // Persist to database
      const cmdRecord = await saveCommand({
        transcript,
        language: agentResult.intent.language,
        intent: agentResult.intent.intent,
        priority: agentResult.intent.priority,
        status: 'completed',
        pipeline_trace: agentResult.pipeline,
        response_text: agentResult.response.text,
      });

      if (agentResult.data?.task) {
        await saveTask({
          ...agentResult.data.task,
          command_id: cmdRecord?.id,
        });
      }
      if (agentResult.data?.reminder) {
        await saveReminder(agentResult.data.reminder);
      }
      if (agentResult.data?.trip) {
        await saveTrip(agentResult.data.trip);
      }
      if (agentResult.data?.incident) {
        await saveIncident(agentResult.data.incident);
      }

      // Refresh counts
      fetchTasks().then((tasks) => {
        setActiveTasks(tasks.filter((t) => t.status === 'pending' || t.status === 'in_progress').length);
      });
      fetchReminders().then((reminders) => {
        setUpcomingReminders(reminders.filter((r) => r.status === 'pending').length);
      });

      setMicState('success');

      // Speak the response
      if (voiceEnabled) {
        speak(agentResult.response.voice, agentResult.intent.language === 'hi' ? 'hi-IN' : 'en-IN');
      }

      // Reset to idle after a delay
      setTimeout(() => {
        setMicState('idle');
        setProcessing(false);
        processingRef.current = false;
      }, 3000);
    },
    [getLocation, speak, voiceEnabled],
  );

  const handleMicClick = useCallback(() => {
    if (micState === 'listening') {
      // Will be handled by speech recognition onend
      return;
    }
    if (processing) return;

    // Request mic permission and start listening
    navigator.mediaDevices
      ?.getUserMedia({ audio: true })
      .then((stream) => {
        stream.getTracks().forEach((t) => t.stop());
        startListening();
      })
      .catch(() => {
        // Fallback: focus text input
        const input = document.getElementById('text-command-input') as HTMLInputElement;
        input?.focus();
      });
  }, [micState, processing]);

  const { isListening, interimTranscript, transcript, isSupported, start, stop } = useSpeechRecognition({
    lang: 'en-IN',
    onFinalTranscript: (text) => {
      stop();
      processCommand(text);
    },
  });

  const startListening = () => {
    setMicState('listening');
    start();
  };

  const handleTextSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!textCommand.trim()) return;
    processCommand(textCommand.trim());
    setTextCommand('');
  };

  const handleQuickAction = (command: string) => {
    processCommand(command);
  };

  return (
    <div className="space-y-6">
      {/* Status bar */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
        <StatCard label="Active Tasks" value={activeTasks} icon={<span className="text-sm">T</span>} />
        <StatCard label="Upcoming Reminders" value={upcomingReminders} icon={<Bell className="w-3.5 h-3.5" />} />
        <StatCard
          label="Emergency"
          value={emergencyActive ? 'ACTIVE' : 'Clear'}
          urgent={emergencyActive}
          icon={<AlertTriangle className="w-3.5 h-3.5" />}
        />
        <StatCard label="Voice" value={voiceEnabled ? 'On' : 'Off'} icon={<Sparkles className="w-3.5 h-3.5" />} onClick={toggleVoice} />
      </div>

      <div className="grid lg:grid-cols-5 gap-6">
        {/* Left: Mic + Input */}
        <div className="lg:col-span-2 space-y-4">
          {/* Mic Card */}
          <div className="bg-white rounded-2xl border border-stone-200 p-6 flex flex-col items-center">
            <MicButton
              state={isListening ? 'listening' : micState}
              isListening={isListening}
              onClick={handleMicClick}
              disabled={processing && !isListening}
            />

            {/* Transcript display */}
            {(transcript || interimTranscript) && (
              <div className="mt-4 w-full px-4 py-3 bg-stone-50 rounded-xl">
                <p className="text-xs text-stone-400 mb-1">Transcript</p>
                <p className="text-sm text-stone-800">
                  {transcript}
                  {interimTranscript && <span className="text-stone-400"> {interimTranscript}</span>}
                </p>
              </div>
            )}

            {!isSupported && (
              <p className="mt-3 text-xs text-amber-600 bg-amber-50 px-3 py-1.5 rounded-lg">
                Voice input not supported — use text below
              </p>
            )}
          </div>

          {/* Text Command Input */}
          <form onSubmit={handleTextSubmit} className="bg-white rounded-2xl border border-stone-200 p-4">
            <label htmlFor="text-command-input" className="text-xs font-medium text-stone-500 mb-2 block">
              Tell Wani what you need
            </label>
            <div className="flex gap-2">
              <input
                id="text-command-input"
                type="text"
                value={textCommand}
                onChange={(e) => setTextCommand(e.target.value)}
                placeholder="e.g. nearest hospital find karo..."
                className="flex-1 px-3.5 py-2.5 bg-stone-50 border border-stone-200 rounded-xl text-sm text-stone-900 placeholder-stone-400 focus:outline-none focus:border-stone-400 transition-colors"
              />
              <button
                type="submit"
                disabled={!textCommand.trim() || processing}
                className="px-3 py-2.5 bg-stone-900 hover:bg-stone-800 disabled:opacity-40 text-white rounded-xl transition-colors flex items-center justify-center"
                aria-label="Send command"
              >
                <Send className="w-4 h-4" />
              </button>
            </div>
          </form>

          {/* Quick Actions */}
          <div className="bg-white rounded-2xl border border-stone-200 p-4">
            <p className="text-xs font-medium text-stone-500 mb-3">Quick Actions</p>
            <div className="grid grid-cols-2 gap-2">
              {QUICK_ACTIONS.map((action) => (
                <button
                  key={action.id}
                  onClick={() => handleQuickAction(action.command)}
                  disabled={processing}
                  className="flex items-center gap-2 px-3 py-2.5 bg-stone-50 hover:bg-stone-100 disabled:opacity-40 rounded-xl text-xs font-medium text-stone-700 transition-colors text-left"
                >
                  <QuickActionIcon icon={action.icon} />
                  <span>{action.label}</span>
                </button>
              ))}
            </div>
          </div>
        </div>

        {/* Right: Pipeline + Results */}
        <div className="lg:col-span-3 space-y-4">
          {pipelineSteps.length > 0 && (
            <PipelineVisualizer steps={pipelineSteps} explanation={explanation} />
          )}

          {result && <ResultPanel result={result} />}

          {!result && !processing && (
            <div className="bg-white rounded-2xl border border-stone-200 p-8 text-center">
              <div className="w-16 h-16 rounded-2xl bg-stone-100 flex items-center justify-center mx-auto mb-4">
                <Sparkles className="w-7 h-7 text-stone-400" />
              </div>
              <h3 className="text-base font-semibold text-stone-900 mb-1">Ready to help</h3>
              <p className="text-sm text-stone-500 max-w-sm mx-auto">
                Tap the microphone or type a command. Wani understands Hindi, English, and Hinglish.
              </p>
              <div className="mt-4 flex flex-wrap gap-2 justify-center">
                <Link to="/tasks" className="text-xs text-stone-600 hover:text-stone-900 underline">View tasks</Link>
                <Link to="/history" className="text-xs text-stone-600 hover:text-stone-900 underline">Command history</Link>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

function StatCard({ label, value, icon, urgent, onClick }: { label: string; value: string | number; icon: React.ReactNode; urgent?: boolean; onClick?: () => void }) {
  return (
    <button
      onClick={onClick}
      className={`text-left bg-white rounded-xl border p-3 transition-colors ${urgent ? 'border-red-300 bg-red-50' : 'border-stone-200'} ${onClick ? 'hover:border-stone-300 cursor-pointer' : 'cursor-default'}`}
    >
      <div className={`flex items-center gap-1.5 mb-1 ${urgent ? 'text-red-600' : 'text-stone-400'}`}>
        {icon}
        <span className="text-[10px] font-medium uppercase tracking-wide">{label}</span>
      </div>
      <p className={`text-lg font-bold ${urgent ? 'text-red-700' : 'text-stone-900'}`}>{value}</p>
    </button>
  );
}

function QuickActionIcon({ icon }: { icon: string }) {
  const cls = 'w-4 h-4 text-stone-500';
  switch (icon) {
    case 'ambulance': return <AlertTriangle className={cls} />;
    case 'bell': return <Bell className={cls} />;
    case 'plane': return <Plane className={cls} />;
    case 'accessibility': return <Accessibility className={cls} />;
    default: return <Sparkles className={cls} />;
  }
}
