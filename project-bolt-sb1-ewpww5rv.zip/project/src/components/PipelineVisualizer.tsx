import type { PipelineStep } from '@/types';
import { Check, Loader2, AlertCircle, Clock } from 'lucide-react';

interface PipelineVisualizerProps {
  steps: PipelineStep[];
  explanation?: string;
}

const STEP_ICONS: Record<string, string> = {
  voice_received: 'Voice Received',
  language_detected: 'Language Detected',
  intent_detected: 'Intent Detected',
  content_extraction: 'Content Extraction',
  tool_selection: 'Tool Selection',
  tool_execution: 'Tool Execution',
  result_verification: 'Result Verification',
  task_creation: 'Task Creation',
  response_generation: 'Response Generation',
};

export default function PipelineVisualizer({ steps, explanation }: PipelineVisualizerProps) {
  if (steps.length === 0) return null;

  return (
    <div className="bg-white rounded-2xl border border-stone-200 overflow-hidden">
      <div className="px-5 py-4 border-b border-stone-100">
        <h3 className="text-sm font-semibold text-stone-900">Agent Pipeline</h3>
        <p className="text-xs text-stone-500 mt-0.5">Real-time processing trace</p>
      </div>

      <div className="divide-y divide-stone-50">
        {steps.map((step, i) => (
          <PipelineStepRow key={i} step={step} index={i} />
        ))}
      </div>

      {explanation && (
        <div className="px-5 py-4 bg-stone-50 border-t border-stone-100">
          <div className="flex gap-2.5">
            <div className="flex-shrink-0 w-5 h-5 rounded-full bg-amber-100 flex items-center justify-center mt-0.5">
              <span className="text-[10px]">?</span>
            </div>
            <div>
              <p className="text-xs font-semibold text-stone-700 mb-0.5">Why this action?</p>
              <p className="text-xs text-stone-600 leading-relaxed">{explanation}</p>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

function PipelineStepRow({ step, index }: { step: PipelineStep; index: number }) {
  const label = STEP_ICONS[step.step] || step.step;

  return (
    <div className="flex items-center gap-3 px-5 py-3 transition-colors">
      {/* Status icon */}
      <div className="flex-shrink-0">
        {step.status === 'done' && (
          <div className="w-6 h-6 rounded-full bg-emerald-100 flex items-center justify-center">
            <Check className="w-3.5 h-3.5 text-emerald-600" strokeWidth={3} />
          </div>
        )}
        {step.status === 'running' && (
          <div className="w-6 h-6 rounded-full bg-blue-100 flex items-center justify-center">
            <Loader2 className="w-3.5 h-3.5 text-blue-600 animate-spin" />
          </div>
        )}
        {step.status === 'pending' && (
          <div className="w-6 h-6 rounded-full bg-stone-100 flex items-center justify-center">
            <span className="text-[10px] text-stone-400">{index + 1}</span>
          </div>
        )}
        {step.status === 'error' && (
          <div className="w-6 h-6 rounded-full bg-red-100 flex items-center justify-center">
            <AlertCircle className="w-3.5 h-3.5 text-red-600" />
          </div>
        )}
      </div>

      {/* Content */}
      <div className="flex-1 min-w-0">
        <div className="flex items-center justify-between gap-2">
          <span className={`text-sm font-medium ${step.status === 'done' ? 'text-stone-900' : step.status === 'running' ? 'text-blue-600' : 'text-stone-400'}`}>
            {label}
          </span>
          {step.durationMs != null && (
            <span className="flex items-center gap-0.5 text-[10px] text-stone-400">
              <Clock className="w-3 h-3" />
              {(step.durationMs / 1000).toFixed(1)}s
            </span>
          )}
        </div>
        {step.detail && (
          <p className="text-xs text-stone-500 mt-0.5 truncate">{step.detail}</p>
        )}
      </div>
    </div>
  );
}
