import { NavLink, Link } from 'react-router-dom';
import { AudioLines, LayoutDashboard, ListTodo, History, Settings, Plane } from 'lucide-react';

export default function Layout({ children }: { children: React.ReactNode }) {
  return (
    <div className="min-h-screen bg-stone-50 flex flex-col">
      {/* Header */}
      <header className="sticky top-0 z-40 bg-white/80 backdrop-blur-lg border-b border-stone-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between">
          <Link to="/" className="flex items-center gap-2.5 group">
            <div className="w-9 h-9 rounded-xl bg-stone-900 flex items-center justify-center transition-transform group-hover:scale-105">
              <AudioLines className="w-5 h-5 text-white" strokeWidth={2.5} />
            </div>
            <div>
              <span className="text-lg font-bold text-stone-900 tracking-tight">Wani</span>
              <span className="hidden sm:inline text-xs text-stone-500 ml-1.5">Talk. Understand. Act.</span>
            </div>
          </Link>

          <nav className="flex items-center gap-1">
            <NavItem to="/" icon={<LayoutDashboard className="w-4 h-4" />} label="Dashboard" />
            <NavItem to="/tasks" icon={<ListTodo className="w-4 h-4" />} label="Tasks" />
            <NavItem to="/history" icon={<History className="w-4 h-4" />} label="History" />
            <NavItem to="/trips" icon={<Plane className="w-4 h-4" />} label="Trips" />
            <NavItem to="/settings" icon={<Settings className="w-4 h-4" />} label="Settings" />
          </nav>
        </div>
      </header>

      {/* Main */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-6 sm:py-8">
        {children}
      </main>

      {/* Footer */}
      <footer className="border-t border-stone-200 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-12 flex items-center justify-between text-xs text-stone-400">
          <span>Wani — Wise AI Agent</span>
          <span>Demo mode active</span>
        </div>
      </footer>
    </div>
  );
}

function NavItem({ to, icon, label }: { to: string; icon: React.ReactNode; label: string }) {
  return (
    <NavLink
      to={to}
      end={to === '/'}
      className={({ isActive }) =>
        `flex items-center gap-1.5 px-3 py-2 rounded-lg text-sm font-medium transition-colors ${
          isActive
            ? 'bg-stone-900 text-white'
            : 'text-stone-600 hover:text-stone-900 hover:bg-stone-100'
        }`
      }
    >
      {icon}
      <span className="hidden sm:inline">{label}</span>
    </NavLink>
  );
}
