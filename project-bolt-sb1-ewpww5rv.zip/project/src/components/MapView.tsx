import { useEffect, useRef } from 'react';
import { MapContainer, TileLayer, Marker, Polyline, Popup } from 'react-leaflet';
import L from 'leaflet';
import 'leaflet/dist/leaflet.css';
import type { GeoLocation, Hospital, RouteInfo } from '@/types';

// Fix default marker icons (Leaflet's CSS-based icons break with bundlers)
delete (L.Icon.Default.prototype as any)._getIconUrl;
L.Icon.Default.mergeOptions({
  iconRetinaUrl: 'https://unpkg.com/leaflet@1.9.4/dist/images/marker-icon-2x.png',
  iconUrl: 'https://unpkg.com/leaflet@1.9.4/dist/images/marker-icon.png',
  shadowUrl: 'https://unpkg.com/leaflet@1.9.4/dist/images/marker-shadow.png',
});

// Custom emergency marker icon
const emergencyIcon = L.divIcon({
  className: 'custom-emergency-marker',
  html: '<div style="width:28px;height:28px;background:#dc2626;border-radius:50% 50% 50% 0;transform:rotate(-45deg);border:2px solid #fff;box-shadow:0 2px 6px rgba(0,0,0,.3);display:flex;align-items:center;justify-content:center;"><span style="transform:rotate(45deg);font-size:14px;">H</span></div>',
  iconSize: [28, 28],
  iconAnchor: [14, 28],
});

const userIcon = L.divIcon({
  className: 'custom-user-marker',
  html: '<div style="width:18px;height:18px;background:#2563eb;border-radius:50%;border:3px solid #fff;box-shadow:0 0 0 4px rgba(37,99,235,.3);"></div>',
  iconSize: [18, 18],
  iconAnchor: [9, 9],
});

interface MapViewProps {
  userLocation?: GeoLocation | null;
  hospital?: Hospital | null;
  route?: RouteInfo | null;
  emergency?: boolean;
}

export default function MapView({ userLocation, hospital, route, emergency }: MapViewProps) {
  const mapRef = useRef<L.Map | null>(null);

  // Center on hospital or user or default
  const center: [number, number] = hospital
    ? [hospital.lat, hospital.lng]
    : userLocation
      ? [userLocation.lat, userLocation.lng]
      : [28.6139, 77.209];

  // Fit bounds when both points exist
  useEffect(() => {
    if (!mapRef.current || !userLocation || !hospital) return;
    const bounds = L.latLngBounds(
      [userLocation.lat, userLocation.lng],
      [hospital.lat, hospital.lng],
    );
    mapRef.current.fitBounds(bounds, { padding: [50, 50] });
  }, [userLocation, hospital]);

  return (
    <MapContainer
      center={center}
      zoom={13}
      scrollWheelZoom={true}
      className="w-full h-full rounded-2xl z-0"
      ref={(map) => { if (map) mapRef.current = map; }}
    >
      <TileLayer
        attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
        url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
      />

      {userLocation && (
        <Marker position={[userLocation.lat, userLocation.lng]} icon={userIcon}>
          <Popup>
            <strong>Your Location</strong>
            <br />
            {userLocation.label}
          </Popup>
        </Marker>
      )}

      {hospital && (
        <Marker
          position={[hospital.lat, hospital.lng]}
          icon={emergency ? emergencyIcon : undefined}
        >
          <Popup>
            <strong>{hospital.name}</strong>
            <br />
            {hospital.address}
            <br />
            {hospital.distanceKm} km · {hospital.travelTimeMin} min
            <br />
            Emergency: {hospital.emergency ? 'Yes' : 'No'}
          </Popup>
        </Marker>
      )}

      {route && route.waypoints.length > 0 && (
        <Polyline
          positions={route.waypoints}
          pathOptions={{
            color: emergency ? '#dc2626' : '#2563eb',
            weight: 4,
            opacity: 0.8,
            dashArray: emergency ? '10, 6' : undefined,
          }}
        />
      )}
    </MapContainer>
  );
}
