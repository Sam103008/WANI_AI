import type { AgentResult } from '@/types';
import { MapPin, Clock, Phone, Navigation, Building2, Accessibility, AlertTriangle, Siren } from 'lucide-react';
import MapView from './MapView';

interface ResultPanelProps {
  result: AgentResult;
}

export default function ResultPanel({ result }: ResultPanelProps) {
  const { intent, data, response } = result;
  const isEmergency = intent.isEmergency;

  return (
    <div className="space-y-4">
      {/* Emergency Banner */}
      {isEmergency && (
        <div className="bg-red-50 border-2 border-red-200 rounded-2xl p-4 animate-pulse-slow">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-red-600 flex items-center justify-center flex-shrink-0">
              <Siren className="w-5 h-5 text-white" />
            </div>
            <div>
              <p className="text-sm font-bold text-red-900">EMERGENCY MODE ACTIVATED</p>
              <p className="text-xs text-red-700">Priority: Critical — Medical Emergency</p>
            </div>
          </div>
        </div>
      )}

      {/* Hospital / Navigation Result */}
      {data?.hospital && (
        <div className="bg-white rounded-2xl border border-stone-200 overflow-hidden">
          <div className="px-5 py-4 border-b border-stone-100 flex items-center gap-2">
            <Building2 className="w-4 h-4 text-stone-700" />
            <h3 className="text-sm font-semibold text-stone-900">Nearest Hospital</h3>
          </div>
          <div className="p-5 space-y-3">
            <div>
              <p className="text-lg font-bold text-stone-900">{data.hospital.name}</p>
              <p className="text-sm text-stone-500 flex items-center gap-1.5 mt-1">
                <MapPin className="w-3.5 h-3.5" />
                {data.hospital.address}
              </p>
            </div>

            <div className="grid grid-cols-2 gap-3">
              <InfoCard icon={<Navigation className="w-4 h-4" />} label="Distance" value={`${data.hospital.distanceKm} km`} />
              <InfoCard icon={<Clock className="w-4 h-4" />} label="Travel Time" value={`${data.route?.travelTimeMin || data.hospital.travelTimeMin} min`} />
            </div>

            <div className="flex items-center gap-4 text-xs">
              <span className={`px-2.5 py-1 rounded-full font-medium ${data.hospital.emergency ? 'bg-red-100 text-red-700' : 'bg-stone-100 text-stone-600'}`}>
                {data.hospital.emergency ? 'Emergency: Yes' : 'Emergency: No'}
              </span>
              <a
                href={`tel:${data.hospital.phone}`}
                className="flex items-center gap-1 text-stone-600 hover:text-stone-900"
              >
                <Phone className="w-3.5 h-3.5" />
                {data.hospital.phone}
              </a>
            </div>

            {data.hospital.accessibility.length > 0 && (
              <div className="flex items-start gap-2 pt-2 border-t border-stone-50">
                <Accessibility className="w-4 h-4 text-stone-600 mt-0.5" />
                <div>
                  <p className="text-xs font-medium text-stone-700">Accessibility</p>
                  <p className="text-xs text-stone-500">{data.hospital.accessibility.join(', ')}</p>
                </div>
              </div>
            )}

            {/* Dispatch confirmation for emergencies */}
            {isEmergency && (
              <div className="mt-3 p-3 bg-amber-50 border border-amber-200 rounded-xl">
                <div className="flex items-start gap-2">
                  <AlertTriangle className="w-4 h-4 text-amber-600 mt-0.5 flex-shrink-0" />
                  <div className="flex-1">
                    <p className="text-xs font-semibold text-amber-900">Emergency Action Prepared</p>
                    <p className="text-xs text-amber-700 mt-0.5">
                      Route calculated and task created. No automatic dispatch — confirm below to proceed.
                    </p>
                    <button className="mt-2 px-3 py-1.5 bg-amber-600 hover:bg-amber-700 text-white text-xs font-medium rounded-lg transition-colors">
                      Confirm Dispatch
                    </button>
                  </div>
                </div>
              </div>
            )}
          </div>
        </div>
      )}

      {/* Map */}
      {data?.location && (data?.hospital || data?.route) && (
        <div className="bg-white rounded-2xl border border-stone-200 overflow-hidden">
          <div className="px-5 py-4 border-b border-stone-100">
            <h3 className="text-sm font-semibold text-stone-900">Route Map</h3>
          </div>
          <div className="h-72 sm:h-80">
            <MapView
              userLocation={data.location}
              hospital={data.hospital || null}
              route={data.route || null}
              emergency={isEmergency}
            />
          </div>
          {data?.route && (
            <div className="px-5 py-3 border-t border-stone-100 flex items-center justify-between text-xs text-stone-600">
              <span>Route: {data.route.distanceKm} km · {data.route.travelTimeMin} min</span>
              <span className="capitalize">Mode: {data.route.mode}</span>
            </div>
          )}
        </div>
      )}

      {/* Trip Plan */}
      {data?.trip && data.trip.days && (
        <div className="bg-white rounded-2xl border border-stone-200 overflow-hidden">
          <div className="px-5 py-4 border-b border-stone-100">
            <h3 className="text-sm font-semibold text-stone-900">{data.trip.title}</h3>
            <p className="text-xs text-stone-500 mt-0.5">
              {data.trip.destination} · Start: {data.trip.start_date} · Budget: Rs. {data.trip.total_budget}
            </p>
          </div>
          <div className="divide-y divide-stone-50">
            {data.trip.days.map((day, i) => (
              <div key={i} className="p-4">
                <p className="text-sm font-semibold text-stone-900">Day {day.day} — {day.date}</p>
                <p className="text-xs text-stone-500 mb-2">Budget: Rs. {day.budget}</p>
                <div className="space-y-1.5">
                  {day.activities?.map((act, j) => (
                    <div key={j} className="flex items-start gap-2 text-xs">
                      <span className="font-mono text-stone-400 w-12 flex-shrink-0">{act.time}</span>
                      <div className="flex-1">
                        <span className="text-stone-700 font-medium">{act.title}</span>
                        <span className="text-stone-400"> · {act.duration} · Rs. {act.cost}</span>
                      </div>
                    </div>
                  ))}
                </div>
                <p className="text-xs text-stone-400 italic mt-2">{day.notes}</p>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Text Response */}
      <div className="bg-stone-900 rounded-2xl p-5">
        <p className="text-xs text-stone-400 mb-2 font-medium">Response</p>
        <pre className="text-sm text-stone-100 whitespace-pre-wrap font-sans leading-relaxed">{response.text}</pre>
      </div>
    </div>
  );
}

function InfoCard({ icon, label, value }: { icon: React.ReactNode; label: string; value: string }) {
  return (
    <div className="bg-stone-50 rounded-xl p-3">
      <div className="flex items-center gap-1.5 text-stone-400 mb-1">
        {icon}
        <span className="text-xs">{label}</span>
      </div>
      <p className="text-base font-bold text-stone-900">{value}</p>
    </div>
  );
}
