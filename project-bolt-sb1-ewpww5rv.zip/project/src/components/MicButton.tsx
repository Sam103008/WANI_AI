import { useEffect, useRef } from 'react';
import type { MicState } from '@/types';

interface MicButtonProps {
  state: MicState;
  isListening: boolean;
  onClick: () => void;
  disabled?: boolean;
}

const STATE_COLORS: Record<MicState, { ring: string; glow: string; bg: string; label: string }> = {
  idle: { ring: 'border-stone-300', glow: '', bg: 'bg-stone-900', label: 'Tap to speak' },
  listening: { ring: 'border-blue-400', glow: 'shadow-[0_0_40px_rgba(37,99,235,0.4)]', bg: 'bg-blue-600', label: 'Listening...' },
  processing: { ring: 'border-amber-400', glow: 'shadow-[0_0_40px_rgba(251,191,36,0.4)]', bg: 'bg-amber-500', label: 'Processing...' },
  understanding: { ring: 'border-violet-400', glow: 'shadow-[0_0_40px_rgba(139,92,246,0.3)]', bg: 'bg-violet-600', label: 'Understanding...' },
  executing: { ring: 'border-cyan-400', glow: 'shadow-[0_0_40px_rgba(6,182,212,0.4)]', bg: 'bg-cyan-600', label: 'Taking action...' },
  success: { ring: 'border-emerald-400', glow: 'shadow-[0_0_40px_rgba(16,185,129,0.4)]', bg: 'bg-emerald-600', label: 'Done' },
  error: { ring: 'border-red-400', glow: 'shadow-[0_0_40px_rgba(220,38,38,0.4)]', bg: 'bg-red-600', label: 'Error' },
};

export default function MicButton({ state, isListening, onClick, disabled }: MicButtonProps) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const animationRef = useRef<number>(0);
  const ripplesRef = useRef<number[]>([]);

  const colors = STATE_COLORS[state];

  // Waveform animation
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const W = canvas.width;
    const H = canvas.height;
    let t = 0;

    const draw = () => {
      ctx.clearRect(0, 0, W, H);
      const active = isListening || state === 'processing' || state === 'understanding' || state === 'executing';
      const bars = 32;
      const barWidth = 3;
      const gap = (W - bars * barWidth) / (bars - 1);
      const centerY = H / 2;

      for (let i = 0; i < bars; i++) {
        let amplitude: number;
        if (active) {
          amplitude = (Math.sin(t * 0.05 + i * 0.3) * 0.5 + 0.5) * (Math.random() * 0.4 + 0.6);
        } else if (state === 'success') {
          amplitude = Math.max(0, 0.5 - t * 0.02) * Math.cos(i * 0.5);
        } else {
          amplitude = 0.04;
        }
        const barH = amplitude * H * 0.7;
        const x = i * (barWidth + gap);
        const y = centerY - barH / 2;

        let color = '#a8a29e';
        if (state === 'listening') color = '#3b82f6';
        else if (state === 'processing' || state === 'understanding') color = '#f59e0b';
        else if (state === 'executing') color = '#06b6d4';
        else if (state === 'success') color = '#10b981';
        else if (state === 'error') color = '#dc2626';

        ctx.fillStyle = color;
        ctx.globalAlpha = active ? 0.85 : 0.3;
        ctx.beginPath();
        ctx.roundRect(x, y, barWidth, barH, 1.5);
        ctx.fill();
      }
      ctx.globalAlpha = 1;
      t++;
      animationRef.current = requestAnimationFrame(draw);
    };

    draw();
    return () => cancelAnimationFrame(animationRef.current);
  }, [isListening, state]);

  // Ripple animation for listening state
  useEffect(() => {
    if (state !== 'listening') {
      ripplesRef.current = [];
      return;
    }
    const interval = setInterval(() => {
      ripplesRef.current.push(0);
    }, 1000);
    return () => clearInterval(interval);
  }, [state]);

  return (
    <div className="flex flex-col items-center gap-4">
      {/* Ripple rings */}
      <div className="relative flex items-center justify-center">
        {state === 'listening' && (
          <>
            <span className="absolute w-20 h-20 rounded-full border-2 border-blue-400 animate-ripple" />
            <span className="absolute w-20 h-20 rounded-full border-2 border-blue-400 animate-ripple" style={{ animationDelay: '0.5s' }} />
          </>
        )}

        <button
          onClick={onClick}
          disabled={disabled}
          className={`relative w-20 h-20 rounded-full ${colors.bg} ${colors.glow} flex items-center justify-center transition-all duration-300 hover:scale-105 active:scale-95 disabled:opacity-50 disabled:cursor-not-allowed`}
          aria-label={colors.label}
        >
          {/* Waveform canvas */}
          <canvas
            ref={canvasRef}
            width={56}
            height={56}
            className="absolute inset-0 m-auto"
          />

          {/* Mic icon overlay when idle */}
          {state === 'idle' && (
            <svg className="w-7 h-7 text-white relative z-10" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
              <path strokeLinecap="round" strokeLinejoin="round" d="M12 18.75a6 6 0 006-6v-1.5m-6 7.5a6 6 0 01-6-6v-1.5m6 7.5v3.75m-3.75 0h7.5M12 15.75a3 3 0 01-3-3V4.5a3 3 0 116 0v8.25a3 3 0 01-3 3z" />
            </svg>
          )}

          {/* Pulse for processing/understanding/executing */}
          {(state === 'processing' || state === 'understanding' || state === 'executing') && (
            <span className="absolute inset-0 rounded-full border-2 border-white/40 animate-ping" />
          )}

          {/* Check for success */}
          {state === 'success' && (
            <svg className="w-8 h-8 text-white relative z-10" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={3}>
              <path strokeLinecap="round" strokeLinejoin="round" d="M4.5 12.75l6 6 9-13.5" />
            </svg>
          )}

          {/* X for error */}
          {state === 'error' && (
            <svg className="w-8 h-8 text-white relative z-10" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={3}>
              <path strokeLinecap="round" strokeLinejoin="round" d="M6 18L18 6M6 6l12 12" />
            </svg>
          )}
        </button>
      </div>

      <div className="text-center">
        <p className={`text-sm font-medium ${state === 'error' ? 'text-red-600' : state === 'success' ? 'text-emerald-600' : 'text-stone-600'}`}>
          {colors.label}
        </p>
      </div>
    </div>
  );
}
