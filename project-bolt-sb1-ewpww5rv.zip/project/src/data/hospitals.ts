import type { Hospital } from '@/types';

// Demo hospital data — realistic entries centered around a default location.
// Used when no live map provider is configured.
export const DEMO_HOSPITALS: Hospital[] = [
  {
    id: 'h1',
    name: 'AIIMS Demo Hospital',
    lat: 28.5689,
    lng: 77.2156,
    address: 'Demo Marg, Sector 12, New Delhi',
    distanceKm: 2.4,
    travelTimeMin: 8,
    emergency: true,
    accessibility: ['wheelchair', 'ramp', 'elevator', 'parking'],
    phone: '+91-11-2658-8500',
  },
  {
    id: 'h2',
    name: 'Safdarjung Demo Medical',
    lat: 28.5632,
    lng: 77.2078,
    address: 'Demo Road, South Campus, New Delhi',
    distanceKm: 3.1,
    travelTimeMin: 11,
    emergency: true,
    accessibility: ['wheelchair', 'ramp'],
    phone: '+91-11-2616-5351',
  },
  {
    id: 'h3',
    name: 'Apollo Demo Clinic',
    lat: 28.5801,
    lng: 77.2234,
    address: 'Demo Enclave, Ring Road, New Delhi',
    distanceKm: 4.7,
    travelTimeMin: 15,
    emergency: false,
    accessibility: ['wheelchair', 'elevator', 'parking'],
    phone: '+91-11-2692-5801',
  },
  {
    id: 'h4',
    name: 'Max Demo Super Speciality',
    lat: 28.5548,
    lng: 77.2501,
    address: 'Demo City, Saket, New Delhi',
    distanceKm: 5.2,
    travelTimeMin: 18,
    emergency: true,
    accessibility: ['wheelchair', 'ramp', 'elevator', 'accessible_toilet', 'parking'],
    phone: '+91-11-2651-5050',
  },
  {
    id: 'h5',
    name: 'Fortis Demo Heart Institute',
    lat: 28.5903,
    lng: 77.1898,
    address: 'Demo Vihar, Sector 62, New Delhi',
    distanceKm: 6.8,
    travelTimeMin: 22,
    emergency: true,
    accessibility: ['wheelchair', 'ramp', 'elevator', 'parking'],
    phone: '+91-11-4713-5000',
  },
];

export function findNearestHospital(
  userLat: number,
  userLng: number,
  requireEmergency: boolean,
  requireAccessible: boolean,
): Hospital[] {
  let candidates = [...DEMO_HOSPITALS];
  if (requireEmergency) candidates = candidates.filter((h) => h.emergency);
  if (requireAccessible)
    candidates = candidates.filter((h) => h.accessibility.includes('wheelchair'));

  // Recompute distances relative to the user location using Haversine
  const withDistance = candidates.map((h) => {
    const d = haversineKm(userLat, userLng, h.lat, h.lng);
    const speedKmH = 18; // ~average city speed for demo
    return { ...h, distanceKm: Math.round(d * 10) / 10, travelTimeMin: Math.round((d / speedKmH) * 60) };
  });

  return withDistance.sort((a, b) => a.distanceKm - b.distanceKm);
}

function haversineKm(lat1: number, lng1: number, lat2: number, lng2: number): number {
  const R = 6371;
  const dLat = ((lat2 - lat1) * Math.PI) / 180;
  const dLng = ((lng2 - lng1) * Math.PI) / 180;
  const a =
    Math.sin(dLat / 2) ** 2 +
    Math.cos((lat1 * Math.PI) / 180) *
      Math.cos((lat2 * Math.PI) / 180) *
      Math.sin(dLng / 2) ** 2;
  return R * 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
}
