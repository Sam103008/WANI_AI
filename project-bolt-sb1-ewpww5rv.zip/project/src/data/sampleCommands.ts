export const SAMPLE_COMMANDS: { text: string; label: string; icon: string }[] = [
  {
    text: 'Nearest hospital find karo aur fastest route batao',
    label: 'Find nearest hospital',
    icon: 'hospital',
  },
  {
    text: 'Tomorrow 10:00 AM ko meeting reminder set karo',
    label: 'Create a reminder for tomorrow',
    icon: 'bell',
  },
  {
    text: 'Plan a 3-day trip to Goa',
    label: 'Plan a 3-day trip',
    icon: 'plane',
  },
  {
    text: 'Find a wheelchair-accessible route to the nearest hospital',
    label: 'Accessibility route',
    icon: 'accessibility',
  },
];

export const QUICK_ACTIONS = [
  { id: 'emergency', label: 'Emergency Hospital', icon: 'ambulance', command: 'Emergency! Nearest hospital find karo, fastest route batao' },
  { id: 'reminder', label: 'Set Reminder', icon: 'bell', command: 'Kal subah 9 baje reminder set karo' },
  { id: 'trip', label: 'Plan Trip', icon: 'plane', command: 'Plan a 3-day trip to Manali' },
  { id: 'accessibility', label: 'Accessibility Route', icon: 'accessibility', command: 'Find wheelchair accessible route to nearest hospital' },
] as const;
