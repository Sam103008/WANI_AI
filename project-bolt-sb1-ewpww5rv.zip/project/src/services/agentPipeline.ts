import type {
  IntentResult,
  PipelineStep,
  AgentResult,
  GeoLocation,
  Hospital,
  RouteInfo,
  TaskRecord,
  ReminderRecord,
  TripRecord,
  IncidentRecord,
  Language,
} from '@/types';
import { extractIntent } from './intentDetector';
import { detectLanguage } from './languageDetector';
import { ALL_TOOLS, DEFAULT_LOCATION } from './tools';

function timestamp(): string {
  return new Date().toISOString();
}

function makeStep(step: string, detail?: string): PipelineStep {
  return { step, status: 'pending', detail, timestamp: timestamp() };
}

function runStep(prev: PipelineStep[], step: string, detail?: string): { steps: PipelineStep[]; step: PipelineStep } {
  const steps = [...prev];
  const newStep = { ...makeStep(step, detail), status: 'running' as const };
  steps.push(newStep);
  return { steps, step: newStep };
}

function finishStep(steps: PipelineStep[], stepName: string, detail: string, durationMs: number): PipelineStep[] {
  return steps.map((s) =>
    s.step === stepName && s.status === 'running'
      ? { ...s, status: 'done' as const, detail, durationMs }
      : s,
  );
}

function delay(ms: number): Promise<void> {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

// --- Build the response text based on intent and data ---
function buildResponse(
  intent: IntentResult,
  data: AgentResult['data'],
  lang: Language,
): { text: string; voice: string } {
  switch (intent.intent) {
    case 'medical_navigation': {
      const hospital = data?.hospital;
      const route = data?.route;
      const loc = data?.location;
      const parts: string[] = [];
      parts.push(intent.isEmergency ? 'EMERGENCY MODE ACTIVATED' : 'Medical Navigation');
      parts.push(`Intent: Medical Navigation`);
      parts.push(`Priority: ${intent.priority.toUpperCase()}`);
      if (loc) parts.push(`Location: ${loc.label}`);
      if (hospital) {
        parts.push(`Nearest Hospital: ${hospital.name}`);
        parts.push(`Distance: ${hospital.distanceKm} km`);
        parts.push(`Address: ${hospital.address}`);
        parts.push(`Emergency: ${hospital.emergency ? 'Yes' : 'No'}`);
        parts.push(`Accessibility: ${hospital.accessibility.join(', ')}`);
        parts.push(`Phone: ${hospital.phone}`);
      }
      if (route) {
        parts.push(`Estimated Travel Time: ${route.travelTimeMin} minutes`);
        parts.push(`Route Mode: ${route.mode}`);
      }
      parts.push(`Status: Route calculated, emergency priority assigned, task created.`);

      const text = parts.join('\n');
      const voice = buildVoiceResponse(intent, data, lang);
      return { text, voice };
    }
    case 'reminder': {
      const reminder = data?.reminder;
      const text = reminder
        ? `Reminder Created\nTitle: ${reminder.title}\nTrigger: ${reminder.trigger_at}${reminder.condition ? `\nCondition: ${JSON.stringify(reminder.condition)}` : ''}\nStatus: Pending`
        : 'Reminder could not be created.';
      const voice = reminder
        ? `Reminder set for ${reminder.title}. ${reminder.condition ? 'Conditional reminder active.' : 'You will be notified at the scheduled time.'}`
        : 'Sorry, I could not create the reminder.';
      return { text, voice };
    }
    case 'trip_planner': {
      const trip = data?.trip;
      if (!trip) return { text: 'Trip plan could not be generated.', voice: 'Sorry, I could not plan the trip.' };
      const lines = [`Trip Plan: ${trip.title}`, `Destination: ${trip.destination}`, `Start Date: ${trip.start_date}`, `Total Budget: Rs. ${trip.total_budget}`, ''];
      for (const day of trip.days || []) {
        lines.push(`Day ${day.day} (${day.date}) — Budget: Rs. ${day.budget}`);
        for (const act of day.activities || []) {
          lines.push(`  ${act.time} — ${act.title} (${act.duration}) — Rs. ${act.cost}`);
        }
        lines.push(`  Notes: ${day.notes}`);
        lines.push('');
      }
      const text = lines.join('\n');
      const voice = `I have planned a ${trip.days?.length || 0}-day trip to ${trip.destination}. Total estimated budget is Rs. ${trip.total_budget}. The trip starts on ${trip.start_date}. Each day includes sightseeing, meals, and activities.`;
      return { text, voice };
    }
    case 'accessibility_route': {
      const hospital = data?.hospital;
      const route = data?.route;
      const parts = ['Accessibility Route'];
      if (hospital) {
        parts.push(`Accessible Hospital: ${hospital.name}`);
        parts.push(`Distance: ${hospital.distanceKm} km`);
        parts.push(`Accessibility: ${hospital.accessibility.join(', ')}`);
      }
      if (route) {
        parts.push(`Travel Time: ${route.travelTimeMin} minutes`);
        parts.push(`Mode: ${route.mode}`);
      }
      const text = parts.join('\n');
      const voice = `I found a wheelchair-accessible route to ${hospital?.name || 'the nearest facility'}. It is ${hospital?.distanceKm || 'a short'} km away, with an estimated travel time of ${route?.travelTimeMin || 'a few'} minutes. The route avoids stairs and includes ramps.`;
      return { text, voice };
    }
    case 'weather_check': {
      const text = 'Weather information retrieved. See details above.';
      const voice = 'The weather has been checked. Current conditions are displayed on screen.';
      return { text, voice };
    }
    case 'create_task': {
      const task = data?.task;
      const text = task
        ? `Task Created\nTitle: ${task.title}\nDescription: ${task.description}\nPriority: ${task.priority}\nStatus: Pending`
        : 'Task could not be created.';
      const voice = task
        ? `Task created: ${task.title}. Priority set to ${task.priority}.`
        : 'Sorry, I could not create the task.';
      return { text, voice };
    }
    default: {
      return {
        text: 'I understood your request. How can I help you further?',
        voice: 'I understood your request. Please tell me more about what you need.',
      };
    }
  }
}

function buildVoiceResponse(intent: IntentResult, data: AgentResult['data'], lang: Language): string {
  const hospital = data?.hospital;
  const route = data?.route;
  const loc = data?.location;

  if (lang === 'hi') {
    const parts: string[] = [];
    if (intent.isEmergency) parts.push('आपातकाल मोड सक्रिय।');
    if (hospital) parts.push(`निकटतम अस्पताल ${hospital.name} है, लगभग ${hospital.distanceKm} किलोमीटर दूर।`);
    if (route) parts.push(`अनुमानित यात्रा समय ${route.travelTimeMin} मिनट है।`);
    parts.push('मार्ग की गणना पूरी हो गई है। आपातकालीन प्राथमिकता निर्धारित की गई है।');
    return parts.join(' ');
  }

  if (lang === 'hinglish') {
    const parts: string[] = [];
    if (intent.isEmergency) parts.push('Emergency mode activate ho gaya hai.');
    if (hospital) parts.push(`Nearest suitable hospital ${hospital.name} hai, approximately ${hospital.distanceKm} km door.`);
    if (route) parts.push(`Estimated travel time ${route.travelTimeMin} minutes hai.`);
    parts.push('Route calculate ho gaya hai, emergency priority assign kar di gayi hai, task create ho gaya hai.');
    return parts.join(' ');
  }

  const parts: string[] = [];
  if (intent.isEmergency) parts.push('Emergency mode has been activated.');
  if (loc) parts.push(`Your current location is ${loc.label}.`);
  if (hospital) parts.push(`The nearest suitable hospital is ${hospital.name}, approximately ${hospital.distanceKm} kilometers away.`);
  if (route) parts.push(`Estimated travel time is ${route.travelTimeMin} minutes.`);
  parts.push('Route has been calculated, emergency priority has been assigned, and a task has been created.');
  return parts.join(' ');
}

function buildExplanation(intent: IntentResult): string {
  switch (intent.intent) {
    case 'medical_navigation':
      return intent.isEmergency
        ? 'Warning: Detected an emergency medical navigation request. The system prioritized finding the nearest suitable hospital and calculating the fastest available route. Emergency priority was assigned to ensure the quickest response.'
        : 'Detected a medical navigation request. Found the nearest hospital and calculated the optimal route.';
    case 'reminder':
      return 'Detected a reminder request. Parsed the time and optional conditions, then created a scheduled reminder.';
    case 'trip_planner':
      return 'Detected a trip planning request. Generated a day-by-day itinerary with activities, budget estimates, and travel notes.';
    case 'accessibility_route':
      return 'Detected an accessibility route request. Searched for wheelchair-accessible facilities and calculated a route that avoids stairs and includes ramps.';
    case 'weather_check':
      return 'Detected a weather query. Retrieved current conditions for your location.';
    case 'create_task':
      return 'Detected a task creation request. Created an actionable task with the extracted details.';
    default:
      return 'Processed your request through the agent pipeline.';
  }
}

// --- Main agent pipeline ---
export async function runAgentPipeline(
  transcript: string,
  browserLocation?: GeoLocation,
): Promise<AgentResult> {
  let steps: PipelineStep[] = [];
  let t0: number;

  // Step 1: Speech converted (already done — record it)
  let r = runStep(steps, 'voice_received', 'Audio captured and converted to text');
  steps = r.steps;
  t0 = Date.now();
  await delay(300);
  steps = finishStep(steps, 'voice_received', `Transcript: "${transcript}"`, Date.now() - t0);

  // Step 2: Language detected
  r = runStep(steps, 'language_detected');
  steps = r.steps;
  t0 = Date.now();
  await delay(200);
  const langResult = detectLanguage(transcript);
  steps = finishStep(steps, 'language_detected', `Language: ${langResult.language} (confidence: ${(langResult.confidence * 100).toFixed(0)}%)`, Date.now() - t0);

  // Step 3: Intent detected
  r = runStep(steps, 'intent_detected');
  steps = r.steps;
  t0 = Date.now();
  await delay(400);
  const intent = extractIntent(transcript);
  steps = finishStep(steps, 'intent_detected', `Intent: ${intent.intent} | Priority: ${intent.priority} | Emergency: ${intent.isEmergency}`, Date.now() - t0);

  // Step 4: Content extraction
  r = runStep(steps, 'content_extraction');
  steps = r.steps;
  t0 = Date.now();
  await delay(300);
  const entitySummary = intent.entities.map((e) => `${e.type}:${e.value}`).join(', ');
  steps = finishStep(steps, 'content_extraction', `Entities: ${entitySummary || 'none'}`, Date.now() - t0);

  // Step 5: Tool selection
  r = runStep(steps, 'tool_selection');
  steps = r.steps;
  t0 = Date.now();
  await delay(200);
  const selectedTools = selectTools(intent);
  steps = finishStep(steps, 'tool_selection', `Tools: ${selectedTools.join(', ')}`, Date.now() - t0);

  // Step 6: Tool execution
  r = runStep(steps, 'tool_execution');
  steps = r.steps;
  t0 = Date.now();
  const data: AgentResult['data'] = {};
  let hospital: Hospital | undefined;
  let route: RouteInfo | undefined;
  let location: GeoLocation | undefined;
  let task: Partial<TaskRecord> | undefined;
  let reminder: Partial<ReminderRecord> | undefined;
  let trip: Partial<TripRecord> | undefined;
  let incident: Partial<IncidentRecord> | undefined;

  try {
    // Get location if needed
    if (intent.requiresLocation) {
      const locResult = await ALL_TOOLS['get_current_location'].execute({
        browserCoords: browserLocation,
      });
      location = locResult.location;
      data.location = location;
    }

    // Medical navigation flow
    if (intent.intent === 'medical_navigation' || intent.intent === 'accessibility_route') {
      const requireAccessible = intent.intent === 'accessibility_route';
      const hospResult = await ALL_TOOLS['search_hospitals'].execute({
        location: location || DEFAULT_LOCATION,
        requireEmergency: intent.isEmergency,
        requireAccessible,
      });
      hospital = hospResult.hospitals[0];
      data.hospital = hospital;

      if (hospital) {
        const routeResult = await ALL_TOOLS['calculate_route'].execute({
          origin: location || DEFAULT_LOCATION,
          destination: { lat: hospital.lat, lng: hospital.lng, name: hospital.name },
          accessible: requireAccessible,
        });
        route = routeResult.route;
        data.route = route;
      }
    }

    // Trip planning
    if (intent.intent === 'trip_planner') {
      const destEntity = intent.entities.find((e) => e.type === 'destination');
      const dayEntity = intent.entities.find((e) => e.type === 'duration');
      const days = dayEntity ? parseInt(dayEntity.value) : 3;
      const destination = destEntity?.value || 'your destination';
      const tripResult = await ALL_TOOLS['trip_planner'].execute({ destination, days });
      trip = tripResult.trip;
      data.trip = trip;
    }

    // Reminder creation
    if (intent.intent === 'reminder') {
      const timeEntity = intent.entities.find((e) => e.type === 'time');
      const dayEntity = intent.entities.find((e) => e.type === 'day');
      const conditionEntity = intent.entities.find((e) => e.type === 'condition');
      const triggerDate = computeTriggerDate(dayEntity?.value);
      const triggerAt = `${triggerDate}T${normalizeTime(timeEntity?.value)}`;
      const reminderResult = await ALL_TOOLS['create_reminder'].execute({
        title: transcript.slice(0, 60),
        triggerAt,
        condition: conditionEntity ? { type: 'traffic', threshold: 'heavy', action: 'remind_earlier' } : undefined,
      });
      reminder = reminderResult.reminder;
      data.reminder = reminder;
    }

    // Task creation (for create_task intent or emergency)
    if (intent.intent === 'create_task' || (intent.isEmergency && intent.intent === 'medical_navigation')) {
      const taskResult = await ALL_TOOLS['create_task'].execute({
        title: buildTaskTitle(intent, hospital, trip),
        description: buildTaskDescription(intent, hospital, route, trip),
        priority: intent.priority,
        location: hospital ? hospital.name : undefined,
      });
      task = taskResult.task;
      data.task = task;
    }

    // Incident record for emergencies
    if (intent.isEmergency) {
      incident = {
        type: intent.intent,
        priority: 'critical',
        location_text: location?.label,
        latitude: location?.lat,
        longitude: location?.lng,
        details: { hospital: hospital?.name, distance: hospital?.distanceKm, travelTime: route?.travelTimeMin },
        status: 'active',
      };
      data.incident = incident;
    }

    steps = finishStep(steps, 'tool_execution', 'All tools executed successfully', Date.now() - t0);
  } catch (err) {
    steps = finishStep(steps, 'tool_execution', `Error: ${(err as Error).message}`, Date.now() - t0);
  }

  // Step 7: Result verification
  r = runStep(steps, 'result_verification');
  steps = r.steps;
  t0 = Date.now();
  await delay(200);
  const validationResult = await ALL_TOOLS['validate_result'].execute({
    data: data,
    expectedType: intent.intent,
  });
  steps = finishStep(steps, 'result_verification', `Valid: ${validationResult.valid} | Verified: ${validationResult.verified}`, Date.now() - t0);

  // Step 8: Task creation (record the action task)
  r = runStep(steps, 'task_creation');
  steps = r.steps;
  t0 = Date.now();
  await delay(200);
  const taskCreated = !!task || !!reminder || !!trip;
  steps = finishStep(steps, 'task_creation', taskCreated ? 'Action task created in database' : 'No task needed for this intent', Date.now() - t0);

  // Step 9: Response generation
  r = runStep(steps, 'response_generation');
  steps = r.steps;
  t0 = Date.now();
  await delay(200);
  const response = buildResponse(intent, data, intent.language);
  steps = finishStep(steps, 'response_generation', 'Visual + voice response ready', Date.now() - t0);

  const explanation = buildExplanation(intent);

  return {
    intent,
    pipeline: steps.map((s) => (s.status === 'running' ? { ...s, status: 'done' as const } : s)),
    response,
    data,
    explanation,
  };
}

function selectTools(intent: IntentResult): string[] {
  const tools: string[] = [];
  switch (intent.intent) {
    case 'medical_navigation':
    case 'accessibility_route':
      tools.push('get_current_location', 'search_hospitals', 'calculate_route', 'estimate_travel_time', 'validate_result');
      if (intent.isEmergency) tools.push('create_task');
      break;
    case 'reminder':
      tools.push('create_reminder', 'validate_result');
      break;
    case 'trip_planner':
      tools.push('trip_planner', 'validate_result');
      break;
    case 'weather_check':
      tools.push('get_current_location', 'weather_check', 'validate_result');
      break;
    case 'create_task':
      tools.push('create_task', 'validate_result');
      break;
    default:
      tools.push('validate_result');
  }
  return tools;
}

function computeTriggerDate(day?: string): string {
  const now = new Date();
  if (day === 'tomorrow' || day === 'kal') {
    now.setDate(now.getDate() + 1);
  }
  return now.toISOString().split('T')[0];
}

function normalizeTime(time?: string): string {
  if (!time) return '09:00';
  const cleaned = time.replace(/\./g, ':').replace(/\s+/g, '').toUpperCase();
  if (cleaned.includes(':')) return cleaned.replace(/AM|PM/i, '').padStart(5, '0');
  if (cleaned.includes('AM') || cleaned.includes('PM')) {
    const num = parseInt(cleaned);
    return `${num.toString().padStart(2, '0')}:00`;
  }
  // "9 baje" etc
  const num = parseInt(cleaned);
  return num ? `${num.toString().padStart(2, '0')}:00` : '09:00';
}

function buildTaskTitle(intent: IntentResult, hospital?: Hospital, trip?: any): string {
  switch (intent.intent) {
    case 'medical_navigation':
      return hospital ? `Navigate to ${hospital.name}` : 'Emergency Hospital Navigation';
    case 'accessibility_route':
      return hospital ? `Accessible route to ${hospital.name}` : 'Accessibility Route';
    case 'trip_planner':
      return trip?.title || 'Trip Plan';
    case 'reminder':
      return 'Reminder';
    case 'create_task':
      return 'New Task';
    default:
      return intent.description;
  }
}

function buildTaskDescription(intent: IntentResult, hospital?: Hospital, route?: RouteInfo, trip?: any): string {
  switch (intent.intent) {
    case 'medical_navigation':
      return hospital
        ? `Emergency: Navigate to ${hospital.name} at ${hospital.address}. Distance: ${hospital.distanceKm}km, Travel time: ${route?.travelTimeMin}min. Phone: ${hospital.phone}`
        : 'Find and navigate to nearest hospital';
    case 'accessibility_route':
      return hospital
        ? `Accessible route to ${hospital.name}. Wheelchair accessible. Distance: ${hospital.distanceKm}km, Travel time: ${route?.travelTimeMin}min`
        : 'Find wheelchair accessible route';
    case 'trip_planner':
      return trip ? `Trip to ${trip.destination} for ${trip.days?.length} days. Budget: Rs. ${trip.total_budget}` : 'Plan a trip';
    default:
      return intent.description;
  }
}
