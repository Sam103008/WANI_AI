import type { Language } from '@/types';

// Detects Hindi, English, or Hindi-English (Hinglish) from a transcript.
// Uses script detection + token ratio — no external API needed.

const DEVANAGARI_RANGE = /[\u0900-\u097F]/;

// Common Hindi/Hinglish words (romanized) that signal Hindi content
const HINGLISH_TOKENS = new Set([
  'hai', 'hain', 'karo', 'karna', 'kahan', 'kaha', 'mere', 'mera', 'meri',
  'paas', 'pass', 'ke', 'ka', 'ki', 'se', 'me', 'mein', 'kar', 'do', 'de',
  'batao', 'bata', 'kal', 'abhi', 'subah', 'shaam', 'raat', 'din', 'ghar',
  'hospital', 'reminder', 'trip', 'plan', 'nearest', 'fastest', 'route',
  'find', 'search', 'emergency', 'accessible', 'wheelchair', 'set',
  'tomorrow', 'today', 'minutes', 'hours', 'ghante', 'minut',
  'nahi', 'nahin', 'haan', 'please', ' Kripya', 'zaroor',
  'jaldi', 'emergency', 'ambulance', 'doctor', 'medical',
]);

export function detectLanguage(text: string): { language: Language; confidence: number } {
  const trimmed = text.trim();
  if (!trimmed) return { language: 'en', confidence: 0.5 };

  const hasDevanagari = DEVANAGARI_RANGE.test(trimmed);

  // Extract romanized tokens
  const tokens = trimmed
    .toLowerCase()
    .replace(/[^\w\s]/g, ' ')
    .split(/\s+/)
    .filter(Boolean);

  if (tokens.length === 0) return { language: 'en', confidence: 0.5 };

  let hindiTokenCount = 0;
  let englishTokenCount = 0;

  for (const token of tokens) {
    if (HINGLISH_TOKENS.has(token)) {
      hindiTokenCount++;
    } else if (/^[a-z]+$/.test(token)) {
      // Heuristic: common English words
      englishTokenCount++;
    }
  }

  if (hasDevanagari && englishTokenCount > 0) {
    return { language: 'hinglish', confidence: 0.9 };
  }
  if (hasDevanagari) {
    return { language: 'hi', confidence: 0.95 };
  }

  const hindiRatio = hindiTokenCount / tokens.length;
  const englishRatio = englishTokenCount / tokens.length;

  if (hindiRatio > 0.2 && englishRatio > 0.2) {
    return { language: 'hinglish', confidence: 0.85 };
  }
  if (hindiRatio > 0.35) {
    return { language: 'hi', confidence: 0.8 };
  }

  return { language: 'en', confidence: 0.8 };
}
