import type { IntentResult, IntentType, Priority, Entity, Language } from '@/types';
import { detectLanguage } from './languageDetector';

// Intent extraction using keyword/pattern matching — simulates LLM JSON output.
// In production this would call an LLM API; here we produce a validated JSON
// structure deterministically so the full pipeline works end-to-end.

interface IntentPattern {
  intent: IntentType;
  keywords: string[];
  priority: Priority;
  requiresLocation: boolean;
  isEmergency: boolean;
  entityType?: string;
  description: string;
}

const PATTERNS: IntentPattern[] = [
  {
    intent: 'medical_navigation',
    keywords: ['hospital', 'hospital find', 'nearest hospital', 'medical', 'emergency', 'ambulance', 'doctor', 'injury', 'accident', 'bleeding', 'chest pain', 'dawai', 'asha', 'emergency medical'],
    priority: 'critical',
    requiresLocation: true,
    isEmergency: true,
    entityType: 'hospital',
    description: 'Emergency medical navigation — find the nearest hospital and fastest route',
  },
  {
    intent: 'accessibility_route',
    keywords: ['wheelchair', 'accessible', 'accessibility', 'disability', 'ramp', 'handicap', 'wheelchair accessible', 'accessible route'],
    priority: 'high',
    requiresLocation: true,
    isEmergency: false,
    entityType: 'accessibility',
    description: 'Find a wheelchair-accessible route to a destination',
  },
  {
    intent: 'reminder',
    keywords: ['reminder', 'remind', 'set karo', 'notify', 'alert', 'yaad', 'reminder set', 'remind me', 'notification'],
    priority: 'normal',
    requiresLocation: false,
    isEmergency: false,
    entityType: 'reminder',
    description: 'Create a reminder or notification',
  },
  {
    intent: 'trip_planner',
    keywords: ['trip', 'plan', 'travel', 'vacation', 'itinerary', 'holiday', 'ghoom', 'trip plan', 'plan a trip', 'day trip'],
    priority: 'normal',
    requiresLocation: false,
    isEmergency: false,
    entityType: 'trip',
    description: 'Plan a multi-day trip with schedule and budget',
  },
  {
    intent: 'weather_check',
    keywords: ['weather', 'mausam', 'temperature', 'forecast', 'rain', 'barish'],
    priority: 'low',
    requiresLocation: true,
    isEmergency: false,
    entityType: 'weather',
    description: 'Check current weather conditions',
  },
  {
    intent: 'create_task',
    keywords: ['task', 'create', 'add', 'make a note', 'note', 'kaam', 'list', 'todo', 'to-do'],
    priority: 'normal',
    requiresLocation: false,
    isEmergency: false,
    entityType: 'task',
    description: 'Create a general task or note',
  },
  {
    intent: 'general_query',
    keywords: ['what', 'how', 'why', 'where', 'kya', 'kaise', 'kyun', 'kahan', 'explain', 'tell me'],
    priority: 'low',
    requiresLocation: false,
    isEmergency: false,
    entityType: 'query',
    description: 'General information query',
  },
];

const EMERGENCY_KEYWORDS = new Set([
  'emergency', 'urgent', 'critical', 'jaldi', 'ambulance', 'accident',
  'bleeding', 'heart attack', 'chest pain', 'stroke', 'unconscious',
  'breathing', 'save', 'help', 'bachao',
]);

function extractEntities(text: string, pattern: IntentPattern): Entity[] {
  const entities: Entity[] = [];
  const lower = text.toLowerCase();

  // Person entities
  const personMatch = lower.match(/\b(mother|father|sister|brother|wife|husband|son|daughter|friend|mother-in-law|mummy|papa|didi|bhai)\b/);
  if (personMatch) entities.push({ type: 'person', value: personMatch[1] });

  // Time entities
  const timeMatch = text.match(/\b(\d{1,2}[:.]?\d{0,2}\s*(?:AM|PM|am|pm)?)\b/) || text.match(/\b(\d{1,2})\s*(?:baje|o.?clock)\b/i);
  if (timeMatch) entities.push({ type: 'time', value: timeMatch[1] });

  // Day entities
  const dayMatch = lower.match(/\b(tomorrow|today|kal|aaj|monday|tuesday|wednesday|thursday|friday|saturday|sunday)\b/);
  if (dayMatch) entities.push({ type: 'day', value: dayMatch[1] });

  // Duration entities
  const durationMatch = text.match(/\b(\d+)[- ]?(?:day|days|din|ghante|hours|minutes|minut)\b/i);
  if (durationMatch) entities.push({ type: 'duration', value: durationMatch[1] });

  // Destination / place
  const tripMatch = text.match(/\b(?:trip to|travel to|visit|ghoom|vacation in|holiday in)\s+([a-zA-Z]+)/i);
  if (tripMatch) entities.push({ type: 'destination', value: tripMatch[1] });

  // Traffic condition
  if (lower.includes('traffic') || lower.includes('jam')) {
    entities.push({ type: 'condition', value: 'traffic' });
  }

  // Entity type from pattern
  if (pattern.entityType) {
    entities.push({ type: pattern.entityType, value: pattern.entityType });
  }

  return entities;
}

export function extractIntent(text: string): IntentResult {
  const lower = text.toLowerCase();
  const { language, confidence } = detectLanguage(text);

  // Score each pattern
  let bestPattern: IntentPattern | null = null;
  let bestScore = 0;

  for (const pattern of PATTERNS) {
    let score = 0;
    for (const keyword of pattern.keywords) {
      if (lower.includes(keyword)) {
        score += keyword.split(' ').length > 1 ? 2 : 1;
      }
    }
    if (score > bestScore) {
      bestScore = score;
      bestPattern = pattern;
    }
  }

  // Fallback
  if (!bestPattern || bestScore === 0) {
    bestPattern = PATTERNS.find((p) => p.intent === 'general_query')!;
  }

  // Check for emergency escalation
  let priority = bestPattern.priority;
  let isEmergency = bestPattern.isEmergency;
  for (const kw of EMERGENCY_KEYWORDS) {
    if (lower.includes(kw)) {
      isEmergency = true;
      priority = 'critical';
      break;
    }
  }

  const entities = extractEntities(text, bestPattern);

  return {
    intent: bestPattern.intent,
    confidence: Math.min(0.6 + bestScore * 0.1, 0.98),
    language,
    priority,
    entities,
    requiresLocation: bestPattern.requiresLocation,
    isEmergency,
    description: bestPattern.description,
  };
}
