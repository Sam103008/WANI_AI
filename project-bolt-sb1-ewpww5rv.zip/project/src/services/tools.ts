import type { AgentTool, GeoLocation, Hospital, RouteInfo } from '@/types';
import { findNearestHospital, DEMO_HOSPITALS } from '@/data/hospitals';

// Default fallback location (Connaught Place, New Delhi)
const DEFAULT_LOCATION: GeoLocation = {
  lat: 28.6139,
  lng: 77.209,
  label: 'Current Location (Demo — New Delhi)',
};

// --- Tool: Get Current Location ---
export const getCurrentLocation: AgentTool = {
  name: 'get_current_location',
  description: 'Obtain the user current geographic location',
  execute: async (params: { browserCoords?: GeoLocation }) => {
    if (params.browserCoords) return { location: params.browserCoords };
    return { location: DEFAULT_LOCATION };
  },
};

// --- Tool: Search Hospitals ---
export const searchHospitals: AgentTool = {
  name: 'search_hospitals',
  description: 'Search for nearby hospitals relative to a location',
  execute: async (params: {
    location: GeoLocation;
    requireEmergency?: boolean;
    requireAccessible?: boolean;
  }) => {
    const hospitals = findNearestHospital(
      params.location.lat,
      params.location.lng,
      params.requireEmergency ?? false,
      params.requireAccessible ?? false,
    );
    return { hospitals, count: hospitals.length };
  },
};

// --- Tool: Calculate Route ---
export const calculateRoute: AgentTool = {
  name: 'calculate_route',
  description: 'Calculate a route between two points with distance and travel time',
  execute: async (params: {
    origin: GeoLocation;
    destination: { lat: number; lng: number; name: string };
    accessible?: boolean;
  }) => {
    const route = computeDemoRoute(
      params.origin.lat,
      params.origin.lng,
      params.destination.lat,
      params.destination.lng,
      params.accessible,
    );
    return { route };
  },
};

// --- Tool: Estimate Travel Time ---
export const estimateTravelTime: AgentTool = {
  name: 'estimate_travel_time',
  description: 'Estimate travel time based on distance and traffic conditions',
  execute: async (params: { distanceKm: number; isEmergency?: boolean }) => {
    const speedKmH = params.isEmergency ? 30 : 18;
    const minutes = Math.round((params.distanceKm / speedKmH) * 60);
    return { travelTimeMin: Math.max(minutes, 1) };
  },
};

// --- Tool: Traffic Check ---
export const checkTraffic: AgentTool = {
  name: 'traffic_check',
  description: 'Check traffic conditions for a route',
  execute: async (_params: { route?: RouteInfo }) => {
    // Demo traffic data
    const level = Math.random() > 0.6 ? 'heavy' : Math.random() > 0.3 ? 'moderate' : 'light';
    return { trafficLevel: level, delayMin: level === 'heavy' ? 12 : level === 'moderate' ? 5 : 0 };
  },
};

// --- Tool: Create Task ---
export const createTask: AgentTool = {
  name: 'create_task',
  description: 'Create an actionable task record',
  execute: async (params: { title: string; description: string; priority: string; location?: string }) => {
    return {
      task: {
        title: params.title,
        description: params.description,
        priority: params.priority,
        status: 'pending' as const,
        location_text: params.location,
      },
    };
  },
};

// --- Tool: Create Reminder ---
export const createReminder: AgentTool = {
  name: 'create_reminder',
  description: 'Create a reminder with optional conditional logic',
  execute: async (params: {
    title: string;
    triggerAt: string;
    condition?: Record<string, any>;
  }) => {
    return {
      reminder: {
        title: params.title,
        trigger_at: params.triggerAt,
        condition: params.condition ?? null,
        status: 'pending' as const,
      },
    };
  },
};

// --- Tool: Trip Planner ---
export const planTrip: AgentTool = {
  name: 'trip_planner',
  description: 'Plan a multi-day trip with activities, schedule and budget',
  execute: async (params: { destination: string; days: number; startDate?: string }) => {
    const trip = generateTripPlan(params.destination, params.days, params.startDate);
    return { trip };
  },
};

// --- Tool: Weather Check ---
export const weatherCheck: AgentTool = {
  name: 'weather_check',
  description: 'Check current weather for a location',
  execute: async (params: { location: GeoLocation }) => {
    const temps = [22, 25, 28, 31, 34, 19, 24];
    const conditions = ['Sunny', 'Partly Cloudy', 'Cloudy', 'Light Rain', 'Clear'];
    const idx = Math.floor(Math.random() * temps.length);
    return {
      weather: {
        temperature: temps[idx],
        condition: conditions[idx % conditions.length],
        humidity: 40 + Math.floor(Math.random() * 40),
        location: params.location.label,
      },
    };
  },
};

// --- Tool: Validate Result ---
export const validateResult: AgentTool = {
  name: 'validate_result',
  description: 'Verify that the tool execution produced a valid result',
  execute: async (params: { data: any; expectedType: string }) => {
    const valid = params.data != null && typeof params.data === 'object';
    return { valid, verified: true, type: params.expectedType };
  },
};

// --- Helper: Compute demo route with waypoints ---
function computeDemoRoute(
  lat1: number,
  lng1: number,
  lat2: number,
  lng2: number,
  accessible?: boolean,
): RouteInfo {
  const distance = haversineKm(lat1, lng1, lat2, lng2);
  const speedKmH = accessible ? 14 : 20;
  const travelTime = Math.round((distance / speedKmH) * 60);

  // Generate intermediate waypoints for a realistic route polyline
  const waypoints: [number, number][] = [[lat1, lng1]];
  const steps = 4;
  for (let i = 1; i < steps; i++) {
    const t = i / steps;
    // Add slight curve to waypoints
    const offset = (Math.sin(t * Math.PI) * 0.003);
    waypoints.push([
      lat1 + (lat2 - lat1) * t + offset,
      lng1 + (lng2 - lng1) * t - offset,
    ]);
  }
  waypoints.push([lat2, lng2]);

  return {
    distanceKm: Math.round(distance * 10) / 10,
    travelTimeMin: Math.max(travelTime, 1),
    waypoints,
    mode: accessible ? 'accessible' : 'driving',
  };
}

function haversineKm(lat1: number, lng1: number, lat2: number, lng2: number): number {
  const R = 6371;
  const dLat = ((lat2 - lat1) * Math.PI) / 180;
  const dLng = ((lng2 - lng1) * Math.PI) / 180;
  const a =
    Math.sin(dLat / 2) ** 2 +
    Math.cos((lat1 * Math.PI) / 180) * Math.cos((lat2 * Math.PI) / 180) * Math.sin(dLng / 2) ** 2;
  return R * 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
}

// --- Helper: Generate trip plan ---
function generateTripPlan(destination: string, days: number, startDate?: string) {
  const start = startDate ? new Date(startDate) : new Date(Date.now() + 86400000);
  const dayPlans = [];
  const activityTemplates = [
    { time: '09:00', title: 'Breakfast & Check-out Exploration', duration: '1h', cost: 300 },
    { time: '11:00', title: 'Local Sightseeing', duration: '2h', cost: 500 },
    { time: '13:30', title: 'Lunch at Local Restaurant', duration: '1h', cost: 400 },
    { time: '15:00', title: 'Cultural / Adventure Activity', duration: '3h', cost: 800 },
    { time: '19:00', title: 'Dinner & Evening Stroll', duration: '2h', cost: 600 },
  ];

  let totalBudget = 0;
  for (let d = 0; d < days; d++) {
    const date = new Date(start.getTime() + d * 86400000);
    const activities = activityTemplates.map((a) => ({
      ...a,
      description: `${a.title} in ${destination}`,
      location: destination,
    }));
    const dayBudget = activities.reduce((s, a) => s + a.cost, 0);
    totalBudget += dayBudget;
    dayPlans.push({
      day: d + 1,
      date: date.toISOString().split('T')[0],
      activities,
      budget: dayBudget,
      notes: `Day ${d + 1}: Explore ${destination}. Estimated travel between activities ~20 min.`,
    });
  }

  return {
    title: `${days}-Day Trip to ${destination}`,
    destination,
    start_date: start.toISOString().split('T')[0],
    days: dayPlans,
    total_budget: totalBudget,
  };
}

// Export all tools for the agent
export const ALL_TOOLS: Record<string, AgentTool> = {
  get_current_location: getCurrentLocation,
  search_hospitals: searchHospitals,
  calculate_route: calculateRoute,
  estimate_travel_time: estimateTravelTime,
  traffic_check: checkTraffic,
  create_task: createTask,
  create_reminder: createReminder,
  trip_planner: planTrip,
  weather_check: weatherCheck,
  validate_result: validateResult,
};

export { DEFAULT_LOCATION, DEMO_HOSPITALS };
