import { createClient } from '@supabase/supabase-js';

const supabaseUrl = import.meta.env.VITE_SUPABASE_URL as string;
const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY as string;

export const supabase = createClient(supabaseUrl, supabaseAnonKey);

import type { CommandRecord, TaskRecord, ReminderRecord, TripRecord, IncidentRecord } from '@/types';

// --- Commands ---
export async function saveCommand(record: Omit<CommandRecord, 'id' | 'created_at'>): Promise<CommandRecord | null> {
  const { data, error } = await supabase
    .from('commands')
    .insert({
      transcript: record.transcript,
      language: record.language,
      intent: record.intent,
      priority: record.priority,
      status: record.status,
      pipeline_trace: record.pipeline_trace,
      response_text: record.response_text,
    })
    .select()
    .maybeSingle();
  if (error) {
    console.error('saveCommand error:', error.message);
    return null;
  }
  return data as CommandRecord | null;
}

export async function fetchCommands(): Promise<CommandRecord[]> {
  const { data, error } = await supabase
    .from('commands')
    .select('*')
    .order('created_at', { ascending: false })
    .limit(50);
  if (error) {
    console.error('fetchCommands error:', error.message);
    return [];
  }
  return (data as CommandRecord[]) || [];
}

export async function deleteCommand(id: string): Promise<boolean> {
  const { error } = await supabase.from('commands').delete().eq('id', id);
  if (error) {
    console.error('deleteCommand error:', error.message);
    return false;
  }
  return true;
}

export async function clearAllCommands(): Promise<boolean> {
  const { error } = await supabase.from('commands').delete().neq('id', '00000000-0000-0000-0000-000000000000');
  if (error) {
    console.error('clearAllCommands error:', error.message);
    return false;
  }
  return true;
}

// --- Tasks ---
export async function fetchTasks(): Promise<TaskRecord[]> {
  const { data, error } = await supabase
    .from('tasks')
    .select('*')
    .order('created_at', { ascending: false });
  if (error) {
    console.error('fetchTasks error:', error.message);
    return [];
  }
  return (data as TaskRecord[]) || [];
}

export async function saveTask(task: Partial<TaskRecord>): Promise<TaskRecord | null> {
  const payload: Record<string, any> = {
    title: task.title,
    description: task.description,
    priority: task.priority || 'normal',
    status: task.status || 'pending',
    location_text: task.location_text,
    latitude: task.latitude,
    longitude: task.longitude,
    metadata: task.metadata || {},
  };
  if (task.command_id) payload.command_id = task.command_id;

  if (task.id) {
    const { data, error } = await supabase
      .from('tasks')
      .update({ ...payload, updated_at: new Date().toISOString() })
      .eq('id', task.id)
      .select()
      .maybeSingle();
    if (error) { console.error('updateTask error:', error.message); return null; }
    return data as TaskRecord | null;
  }
  const { data, error } = await supabase
    .from('tasks')
    .insert(payload)
    .select()
    .maybeSingle();
  if (error) { console.error('saveTask error:', error.message); return null; }
  return data as TaskRecord | null;
}

export async function deleteTask(id: string): Promise<boolean> {
  const { error } = await supabase.from('tasks').delete().eq('id', id);
  if (error) { console.error('deleteTask error:', error.message); return false; }
  return true;
}

// --- Reminders ---
export async function fetchReminders(): Promise<ReminderRecord[]> {
  const { data, error } = await supabase
    .from('reminders')
    .select('*')
    .order('trigger_at', { ascending: true });
  if (error) { console.error('fetchReminders error:', error.message); return []; }
  return (data as ReminderRecord[]) || [];
}

export async function saveReminder(reminder: Partial<ReminderRecord>): Promise<ReminderRecord | null> {
  const payload: Record<string, any> = {
    title: reminder.title,
    trigger_at: reminder.trigger_at,
    condition: reminder.condition,
    status: reminder.status || 'pending',
  };
  if (reminder.task_id) payload.task_id = reminder.task_id;

  const { data, error } = await supabase
    .from('reminders')
    .insert(payload)
    .select()
    .maybeSingle();
  if (error) { console.error('saveReminder error:', error.message); return null; }
  return data as ReminderRecord | null;
}

export async function deleteReminder(id: string): Promise<boolean> {
  const { error } = await supabase.from('reminders').delete().eq('id', id);
  if (error) { console.error('deleteReminder error:', error.message); return false; }
  return true;
}

// --- Trips ---
export async function fetchTrips(): Promise<TripRecord[]> {
  const { data, error } = await supabase
    .from('trips')
    .select('*')
    .order('created_at', { ascending: false });
  if (error) { console.error('fetchTrips error:', error.message); return []; }
  return (data as TripRecord[]) || [];
}

export async function saveTrip(trip: Partial<TripRecord>): Promise<TripRecord | null> {
  const payload: Record<string, any> = {
    title: trip.title,
    destination: trip.destination,
    start_date: trip.start_date,
    days: trip.days,
    total_budget: trip.total_budget,
  };
  const { data, error } = await supabase
    .from('trips')
    .insert(payload)
    .select()
    .maybeSingle();
  if (error) { console.error('saveTrip error:', error.message); return null; }
  return data as TripRecord | null;
}

export async function deleteTrip(id: string): Promise<boolean> {
  const { error } = await supabase.from('trips').delete().eq('id', id);
  if (error) { console.error('deleteTrip error:', error.message); return false; }
  return true;
}

// --- Incidents ---
export async function fetchIncidents(): Promise<IncidentRecord[]> {
  const { data, error } = await supabase
    .from('incidents')
    .select('*')
    .order('created_at', { ascending: false });
  if (error) { console.error('fetchIncidents error:', error.message); return []; }
  return (data as IncidentRecord[]) || [];
}

export async function saveIncident(incident: Partial<IncidentRecord>): Promise<IncidentRecord | null> {
  const payload: Record<string, any> = {
    type: incident.type,
    priority: incident.priority || 'critical',
    location_text: incident.location_text,
    latitude: incident.latitude,
    longitude: incident.longitude,
    details: incident.details || {},
    status: incident.status || 'active',
  };
  const { data, error } = await supabase
    .from('incidents')
    .insert(payload)
    .select()
    .maybeSingle();
  if (error) { console.error('saveIncident error:', error.message); return null; }
  return data as IncidentRecord | null;
}

export async function updateIncidentStatus(id: string, status: string): Promise<boolean> {
  const { error } = await supabase.from('incidents').update({ status }).eq('id', id);
  if (error) { console.error('updateIncident error:', error.message); return false; }
  return true;
}
