export type Language = 'hi' | 'en' | 'hinglish';

export type MicState =
  | 'idle'
  | 'listening'
  | 'processing'
  | 'understanding'
  | 'executing'
  | 'success'
  | 'error';

export type Priority = 'critical' | 'high' | 'normal' | 'low';

export type TaskStatus = 'pending' | 'in_progress' | 'completed' | 'cancelled';

export type IntentType =
  | 'medical_navigation'
  | 'reminder'
  | 'trip_planner'
  | 'accessibility_route'
  | 'weather_check'
  | 'create_task'
  | 'general_query';

export interface PipelineStep {
  step: string;
  status: 'pending' | 'running' | 'done' | 'error';
  detail?: string;
  timestamp: string;
  durationMs?: number;
}

export interface Entity {
  type: string;
  value: string;
}

export interface IntentResult {
  intent: IntentType;
  confidence: number;
  language: Language;
  priority: Priority;
  entities: Entity[];
  requiresLocation: boolean;
  isEmergency: boolean;
  description: string;
}

export interface GeoLocation {
  lat: number;
  lng: number;
  label: string;
}

export interface Hospital {
  id: string;
  name: string;
  lat: number;
  lng: number;
  address: string;
  distanceKm: number;
  travelTimeMin: number;
  emergency: boolean;
  accessibility: string[];
  phone: string;
}

export interface RouteInfo {
  distanceKm: number;
  travelTimeMin: number;
  waypoints: [number, number][];
  mode: string;
}

export interface AgentTool {
  name: string;
  description: string;
  execute: (params: any) => Promise<any>;
}

export interface CommandRecord {
  id?: string;
  transcript: string;
  language: Language;
  intent: IntentType;
  priority: Priority;
  status: string;
  pipeline_trace: PipelineStep[];
  response_text: string;
  created_at?: string;
}

export interface TaskRecord {
  id?: string;
  title: string;
  description: string;
  priority: Priority;
  status: TaskStatus;
  location_text?: string;
  latitude?: number;
  longitude?: number;
  metadata: Record<string, any>;
  command_id?: string;
  created_at?: string;
  updated_at?: string;
}

export interface ReminderRecord {
  id?: string;
  title: string;
  trigger_at: string;
  condition?: Record<string, any> | null;
  status: string;
  task_id?: string;
  created_at?: string;
}

export interface TripDay {
  day: number;
  date: string;
  activities: TripActivity[];
  budget: number;
  notes: string;
}

export interface TripActivity {
  time: string;
  title: string;
  description: string;
  duration: string;
  cost: number;
  location?: string;
}

export interface TripRecord {
  id?: string;
  title: string;
  destination: string;
  start_date: string;
  days: TripDay[];
  total_budget: number;
  created_at?: string;
}

export interface IncidentRecord {
  id?: string;
  type: string;
  priority: Priority;
  location_text?: string;
  latitude?: number;
  longitude?: number;
  details: Record<string, any>;
  status: string;
  created_at?: string;
}

export interface AgentResult {
  intent: IntentResult;
  pipeline: PipelineStep[];
  response: {
    text: string;
    voice: string;
  };
  data?: {
    location?: GeoLocation;
    hospital?: Hospital;
    route?: RouteInfo;
    task?: Partial<TaskRecord>;
    reminder?: Partial<ReminderRecord>;
    trip?: Partial<TripRecord>;
    incident?: Partial<IncidentRecord>;
  };
  explanation: string;
}
